.searchSF1var<-function(i=2){
"Objective:

 Example #1:> .searchSF1var()

 Example #2:> .searchSF1var(3)
      
";.searchSF1var_(i)}

.searchSF1var_<-function(i){
   .path3<-"http://datayyy.com/"
   if(exists('.sf1Vars')==FALSE){
       .tempPath<-paste0(.path3,"data_R/sf1Vars.RData")
       .sf1Vars<-get(load(url(.tempPath)))
    }

   n<-nrow(.sf1Vars)

  if(typeof(i)=="double"){
       if(abs(i)<=n){
         .show_n_obs(.sf1Vars,i)
       }else{
         cat(" i should be between 1 and ",n,"\n")
       }
   }else{
      #n<-'P1i1'
      i<-toupper(i)
     
      a<-grep(i,toupper(.sf1Vars$VARIABLE))
      b<-grep(i,toupper(.sf1Vars$MEANING))
      d<-grep(i,toupper(.sf1Vars$GROUP))

      if(length(a)!=0)
          e<-a
   
      if(length(b)!=0)
          e<-b

      if(length(d)!=0)
           e<-d

      if(exists("e")==T){   
          final<-.sf1Vars[e,]
      }else{
          final<-"No such variable"
      }
      return(final)
      
   }
}





