.clipr_installation<-function(){
"
  We need the 'clipr' R package for using the .usGDPquarterly and
       the  .data2excel functions (for both Mac and Windows users).
       To install the package, we have the following two ways. 

Method I:
---------
        Just issue the following line to install it
           install.packages('clipr')

Method II:
----------
         Click 'Packages' on the menu bar
              --> Install packages ...
              --> [choose a location] 
              --> [choose 'clipr' from the list]
      
";.clipr_installation_()}

.clipr<<-.clipr_installation

.clipr_installation_<-function(){
cat("
  We need the 'clipr' R package for using the .usGDPquarterly and
       the  .data2excel functions (for both Mac and Windows users).
       To install the package, we have the following two ways. 

Method I:
---------
        Just issue the following line to install it
           install.packages('clipr')

Method II:
----------
         Click 'Packages' on the menu bar
              --> Install packages ...
              --> [choose a location] 
              --> [choose 'clipr' from the list]
")}

