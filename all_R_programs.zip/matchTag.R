.matchTag<-function(myTag,data,type=0){
"Objective: match the keyrod by TAQ column 
   tag    : such as 'AssetsCurrent'  or 'assets current'
   data   : an R data set
   type   : 0 for keeping the original structure
            !=0 using myTag as the name for the value column

   Source of data:http://datayyy.com/data_R/bs2019q1.RData
   Original data: The SEC Financial Statement Data Sets
                  https://www.sec.gov/dera/data/financial-statement-data-sets.html

 Example 1: inData<-'http://datayyy.com/data_R/bs2019q1.RData'
            x<-.load(inData)
            keyword<-'AssetsCurrent'
            a<-.matchTaq(keyword,x)
            dim(x)  #  [1] 177834     10
            dim(a)  # [1] 5643   10

 Example 2: # calculate a current ratio for all companies 
           inData<-'http://datayyy.com/data_R/bs2019q1.RData'
           x<-.load(inData)
           CA<-'assets  current'
           CL<-'liabilities current'
           data_CL<-.matchTag(CL,x,2)
           data_CA<-.matchTag(CA,x,2)
           final<-merge(data_CA,data_CL)
           ratio<-round(final$ASSETSCURRENT/final$LIABILITIESCURRENT,3)
           currentRatio<-data.frame(final[,1:5],ratio)
           names<-colnames(final)
           colnames(currentRatio)<-c(names[1:5],'CurrentRatio')
           head(currentRatio)
              TICKER     CIK    DDATE   PERIOD                        NAME CurrentRatio
            1    ABG 1144980 20171231 20181231 ASBURY AUTOMOTIVE GROUP INC    1.4310854
            2    ABG 1144980 20181231 20181231 ASBURY AUTOMOTIVE GROUP INC    1.2536432
            3   ACLS 1113232 20171231 20181231    AXCELIS TECHNOLOGIES INC    0.6595729
            4   ACLS 1113232 20181231 20181231    AXCELIS TECHNOLOGIES INC    0.7014199
            5    ACM  868857 20180930 20181231                       AECOM    1.0673049
            6    ACM  868857 20181231 20181231                       AECOM    1.0819425
          dim(currentRatio)  #  [1] 777   6

";.matchTag_(myTag,data,type)}

#.mt<-.matchTag

.matchTag_<-function(myTag,x,type){
   myTag<-gsub(" ","",myTag)
   myTag<-toupper(myTag)
   b<-x[toupper(x$TAG)==myTag,]

   if(type==0){
      final<-b
   }else{
     final<-data.frame(b$TICKER,b$NAME,b$DDATE,b$PERIOD,as.numeric(b$VALUE))
     names<-colnames(final)
     n<-length(names)
     names2<-gsub("b.","",names)
     names2[n]<-myTag
     colnames(final)<-names2
 
   }

   final2<-final[order(final$TICKER,final$PERIOD),]
   rownames(final2)<-NULL
   return(final2)
}



