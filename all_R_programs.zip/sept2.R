.sept2<-function(){
"
8:30am
----------------------------------------------
Time: Sep 2, 2021 08:30 PM Eastern Time (US and Canada)
Join Zoom Meeting
https://geneseo.zoom.us/j/87810128618?pwd=MitOOXd2Q0VRYktaRnVoaWMvUzlHUT09


11:30am
----------------------------------------------
Time: Sep 2, 2021 11:30 AM
Join Zoom Meeting
https://geneseo.zoom.us/j/86159184153?pwd=YkVSRUJ6UmdEYlJicnpVbjFRNjNIQT09
 
";.zoom_(i)}

.sept2_<-function(i){
cat("

8:30am
----------------------------------------------
Time: Sep 2, 2021 08:30 PM Eastern Time (US and Canada)
Join Zoom Meeting
https://geneseo.zoom.us/j/87810128618?pwd=MitOOXd2Q0VRYktaRnVoaWMvUzlHUT09



Time: Sep 2, 2021 11:30 AM
Join Zoom Meeting
https://geneseo.zoom.us/j/86159184153?pwd=YkVSRUJ6UmdEYlJicnpVbjFRNjNIQT09

")
}

