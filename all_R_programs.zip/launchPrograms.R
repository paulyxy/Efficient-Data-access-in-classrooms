.launchPrograms<-function(){
     options(warn=-1)


     .loadgetdata(.whichgetdata)

     .loadgetcode(.whichgetcode)


     .loadUtility(.whichUU)
     .uu<<-.utilities
     .u<<-.utilities
     .loadInClassEx(.whichInClassEx)
     .loadFun(.whichFun)

     .loadChapters(.whichChapters)
     .cls()
     .rpy()
}

"


.loadAllChapters()

#  upload YouTube  
.pasteAndSource('/R/youtube.R',..path2)



"