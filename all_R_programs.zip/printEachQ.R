
" old one

     x<-paste('cat(.EX', .chapter,'P',i,')',sep='')

"
.printEachQ<-function(.chapter,i,.n){
   if(i<=.n){
      x<-paste('cat(.C', .chapter,'EXPLAIN',i,')',sep='')
      .runText(x)
   }else{
      cat("Invalid number: input value should between 1 and ",.n, "\n")
   }
}