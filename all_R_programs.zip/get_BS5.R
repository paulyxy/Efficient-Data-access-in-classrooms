.get_BS5<-function(ticker="ibm"){
"Objective: Get Balance Sheet for one of 5: IBM, WMT, AAPL, JNJ, and GM

 Example 1:> .get_BS5('ibm')  
              Window users: launch Excel and paste

      
";.zget_BS5(ticker)}

.zget_BS5<-function(ticker){
   if(exists('.bs5D')==FALSE){
      .bs5D<<-get(load(url("http://datayyy.com/getdata/bs5.RData")))
   }
    
   ticker<-toupper(ticker)

   tickers<-unique(.bs5D$TICKER)

   a<-grep(ticker,tickers)
   if(length(a)==0){
      cat(' Ticker should be one of \n')
      print(tickers)
   }else{
       out<- .bs5D[grep(ticker,.bs5D$TICKER),]
       rownames(out)<-NULL
       .showNobs(out,0)
   }
}




