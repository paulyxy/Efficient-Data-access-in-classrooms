.show_CQ<-function(n=2){
"Objective: CQ stands for Consolidated Quotes
            This is related to high-frequency trading data

 Example 1:> .show_CQ() 

 Example 2:> .show_CQ(-2)

 Example 3:> .show_CQ(0)
             Launch Excel and paste

";.zshow_CQ(n)}

.zshow_CQ<-function(n){
   if(exists('.CQData')==FALSE){
      load(url('http://datayyy.com/data_R/TORQcq.RData'))
      .CQData<<-.x
   }
   .show_n_obs(.CQData,n)
}
