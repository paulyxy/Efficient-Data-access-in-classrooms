"
setwd('c:/yan/teaching/rpy/R')
rm(list=ls(all=TRUE))
source('compareR_Python.R')
source('runtext2.R')
source('cls.R')
save.image('compareR_Python.RData')
"
.compareR_Python<-function(i){
"Comparions between R and Python 
   i  : an integer
        Note: type .compareR_Python
              or   .com
              to see this menu

 Example #1:>.com(1)

 Example #2:>.com(2)

  i    Description 
 --    -------------------
  1    Basics:prompt,case sensitive, alignment,functions
  2    Data input and a true date variable 
  3    Data manipulations 
  4    Data ouput for R and Python 
  5    Loops, logic, graphs 
  6    R/Python packages/Python modules,string manipulations 

";.compareR_Python_(i)}

.crpy<<-.compareR_Python
.com<-.compareR_Python

.nCompare<-6

#  7    Searching lists of R/Python packages/modules
#  8    Show all embeded functions in a packge/module

.compareR_Python_<-function(i){
   if(i<=.nCompare){
      .x<-paste('cat(.compareP',i,')',sep='')
      .runText(.x)
   }else{
     cat("Invalid number: input value should between 1 ",.nCompare, " \n")
   }
}

.compareP1<-"Comparisons between R and Python 
///////////////////////////////////////////
                                      R                       Python 
                                --------------            --------------------
  1) Prompt                       >                       >>>
  2) Case sensitive?              Yes                     Yes
  3) Extra space(s)             does not matter           matter
  4) Alignment                  does not matter           matter 
  5) Power                      10^3 or 10**3             10**3   
  6) Delete variable x          rm(x)                     del x
  7) Commands on the same line  >pv<-10;r<-0.05;n<-2      >>>pv=1;r=0.05;n=2
  8) Assign a value             >pv=100;r<-0.01;3->n      >>>pv=100
  9) Show var/our functions     >ls()                     >>>dir()
 10) Show files                 >dir()                    >>>import os
                                                          >>>os.listdir()
 11) Comments (1st type)        # this is comment         # this is comment
     Comments (2nd type)        \" a pair of double        \"\"\" a pair of 3
                                    quotation marks          double (single) quotation marks 
                                \"                         \"\"\"
 12) Chek the types             >typeof()                 >>>type()
 13) To upper case              >toupper('Mary')          >>>'Mary'.upper()
 14) To lower case              >tolower('Mary')          >>>'Mary'.lower()
 15) Vectror                    >x=c(1,2,3)               >>>x=[1,1,2,3,4]
 16) Counting (index)           # from 1 to n             # from 0 to n-1           
                                >x=c(2,4,0,8)             >>>x=[2,4,0,8]
                                >x[1]                     >>>x[0]
                                  [2]                          2
 17) Current working directory  >getwd()                  >>>os.getcwd()
 18) Change working directory   >setwd(\"c://temp\")        >>>os.chdir(\"c://temp\")

 19) Simple function            >dd<-function(x)          def dd(x):
                                      return(x*2)             return(x*2)
 20) List all the functions                               >>>import math
      from an imported module                             >>>print(dir(math))
///////////////////////////////////////////
"

#Getting the      > today<-Sys.Date()                    import datetime
# year,month,     > year<-format(today,\"%Y\")             today=datetime.date.today() 
# and day         > as.integer(year) #[1] 2021           year=today.strftime(\"%Y\")
                 # for month(day): \"%m\" \"%d\"            # for month(day): \"%m\" \"%d\"

"
 9) Today	  >today<-Sys.Date()                >>>import datetime
                  >today                            >>>today=datetime.datetime.today().date()
 10)Difference       date1<-as.Date(\"2021-04-13\")           import datetime
    between          d2int<-20210520                        date1=datetime.datetime(2021,4,13)
                 d2str<-as.character(d2int)             date2=datetime.datetime(2021,5,20)
                 f0=\"%Y%m%d\"                            diff=date2-date1
                 date2<-as.Date(d2str,format=f0)        print(diff)
                 diff=date2-date1                       diff.days+10
                 as.integer(diff)+10	
                  dates<-seq(date1,by=1,length.out=40)	
"

.compareP2<-"Data input and a true date variable 
///////////////////////////////////////////////
  #  R               Python                        #          R                         Python
  _  ------------    ----------------              -------    ------------              ----------------
  1 >x<-1:10         >>>x=range(1,11)              16)date   >dd=as.Date(\"2021-4-13\")   >>>import datetime
    >print(x)	     >>>print(list(x))                                                  >>>dd=datetime.datetime(2021,4,13)

  2 >set.seed(123)   >>>import numpy as np         17)Add 40 >dd<-as.Date(\"2021-4-13\")  >>>import datetime
                     >>>np.random.seed(123)        18)       >dd+40                     >>>date1=datetime.datetime(2021,4,13)
  3 >runif(10)       >>>np.random.rand(10)                     [1] \"2021-05-23\"         >>>date2=date1+datetime.timedelta(40)
  4 >rnorm(10)       >>>np.random.normal(10)       19)values >d<-\"4/13/2021\"            >>>import pandas as pd
  5 >rnorm(10,5,2)   >>>np.radom.normal(10,5,2)              >f=\"%m/%d/%Y\"              >>>dates=pd.date_range(\"20210313\",periods=40)
  6 >runif(100)      >>>np.random.uniform(100)               >date1=as.Date(d,format=f)
  7 >runif(100,5,2)  >>>np.random.uniform(100,5,2) 20) year  > format(d,\"%Y\")           >>date.year
  8 >x<-c(2,2,1,20)  >>>x=[2,2,1,20]                   month > format(d,\"%m\")           >>date.month    
                     >>>x=(2,2,1,20)                    day  > format(d,\"%d\")           >>date.day
  9 >x=c(4,6,8,NA)   >>>x=(4,6,8,np.nan)           21) year  >as.integer(format(d,'%Y')) 

 10 >read.csv()      >>>pandas.read_csv()          22)       >grep('a','aaabbb')        >>>'this great'.find('this')

 11 >read.table()    >>>pandas.read_table()        23)fun    >dd<-function(x)x*2        >>>def dd(x):return(2*x)

 12 >a<-'clipboard'  >>>pandas.read_clipboard()    24)       >pv_f<-function(fv,r,n){   >>>def pv_f(fv,r,n):
    >read.csv(a)                                                  pv<-fv/(1+r)^n               pv=fv/(1+r)**n
 13 >load()          >>>pandas.read_pickle()                      return(pv)                   return(pv)
    >load(url(( ))                                            }
    >get(load(url()))                              25)

 14 >download.file() >>>from download import download
                     >>>donwload(infile,outfile)
 15 >readline()      >>>input('Enter a  alue])     26)

///////////////////////////////////////////////
"

.compareP3<-"Simple Data manipulation 
///////////////////////////////////////////
  #                R	                      Python                    #      R	                 Python
 ------------      ------------               ------------------------
 1)Combind columns >cbind(x,y)                >>> z=[x,y]
 2)Dimension,      >y<-matrix(1:10,5,2)       >>>import numpy as np
   dim(),length()  >dim(y);col(y);nrow(y)     >>>np.shape(x)   
                   >length(x)
 3)Transpose       >a=matrix(1:10,5,1)        >>>import numpy as np
                   > b=t(a)                   >>>a=np.array([[1, 2], [3, 4],[5,6]])
                                              >>>b=a.T    # transpose
 4) matrix         >as.matrix()               >>>x = np.array([[1, 2], [3, 4]])
                                              >>>m = np.asmatrix(x)
 5) data frame     >df<-data.frame(a,b,c)     >>>df=pandas.DataFrame([a,b,c])
 6) Column names   >colnames(df)              >>>df.columns
 7) Row names/index >rownames(df)             >>>df.index
 8) one column     >df$MKT_RF;df[,1]          >>>df[\"MKT_RF\"];df.iloc[:,1]
 9) head           >head(df);head(df,20)      >>>df.head();df.head(20)
10) tail           >tail(df);tail(df,15)      >>>df.tail();df.tail(15)

11)1st 10 lines    >head(df,10);df[1:10,]     >>>df.head(10);df.iloc[0:9,:]

12) Dimensions	   >dim(df)                   >>>np.shape(df)

13) Number rows    >nrow(df);dim(df)[1]       >>>len(df);np.shape(df)[0]

14) Number col     >ncol(df);dim(df)[2]       >>>numpy.shape(df);numpy.shape(df)[1]

15)rows n1 to n2   >df[n1:n2,]	              >>>df.iloc[(n1-1): (n2-1),:]
16)Col m1 to m2    >df[,m1:m2]                >>>df.iloc[:,n1:n2]

///////////////////////////////////////////
"

.compareP4<-"Data output 
///////////////////////////////////////////
 Nane            R	                         Python 
------------- -------------                   ------------------------          
 save to csv  >write.csv()                     >>>import pandas as pd
                                               >>>df.to_csv()
 save to text >write.table()                   >>>df.to_csv(,sep='\\t')
 save RData   >save()                          >>>df.to_pickle
   Pickle     >saveRDS()
 save to      >writeClipboard()                >>>df.to_clipboard()
  clipboard   >write.csv(x,\"clipboard\")
              >write()                              
              >write.csv(,quote=F,row.names=F) >>>df.to_csv( )
 Excel        >library(xlsx)                   >>>df.to_excel()
              >write.xlsx()
 sink() pair  >sink('all.txt')
              > # more lines between 
              >sink() # end          
 save all     >save.image()
 Temp file    >tt<-temfile()
------------------------------------------------------------------------------------

///////////////////////////////////////////
"





.compareP5<-"Loops and logic 
///////////////////////////////////////////
   Contents         R               Python                    Conents           R                         Python 
-------------   ----------          ------------------        -------------   --------------              ---------------------
1) for loop     for(i in 1:10)      for i in range(1,11):     9) if()         if(rate<0)                  if rate<0:
                     print(i)             print(i)                                print(\"negavie rate\")     print(\"negative rate\")

2)              for(i in 1:10){                               10) if()else()  if(g>0){                   if a>0:                                               
                     print(i)                                                     print(\"a>0\")             print((\"a>0\")
                     # more code                                              }else{                     else:
                }                                                                   print(\"a<=0\")            print(\"a<=0\")
3) double loop  for(i in 1:10){     for i in range(1,11):                     }
                   for(j i 11:20){     for j in range(11,21): 11) logic or    >if(a>0 | b>0)             >>>if(a>0 or  b>0) 
                       k=2*i+j            k=2*i+j             12) logic and   >if(a>0 & b>0)             >>>if(a>0 and b>0)
                       print(k)           print(k)            13) logic no    >if(!a>0)print('a<0')      >>>if not a>0:print('a<0')
                     }                                        14) if else if   grade<-90                  grade=85
                 }                                                           if(grade>=90){             if grade>=90:
4) while loop   i<-1                i=1                                        letter<-\"A\"                  letter=\"A\"
                while(i<10)         for i in range(1,10):                    }else if(grade>=85){       elif grade>=85:
                   print(i)             print(i)                                letter<-\"A-\"                 letter<-\"A-\"    
                   # more code                                               }else if(grade>=80){       elif grade>=80:
                   i<-i+1                                                       letter<-\"B+\"                 letter=\"B+\"
                }                                                            }else if(grade>=75)        elif grade>=75:
                                                                                letter<-\"B\"                letter=\"B\"    
5) embedded     i<-1                i=1                                      }else if(grade>=70){       elif grade>=70:                      
   [break]      while(2==){         while 2==2:                                 letter<-\"B-\"                             letter=\"B-\"
                 # your code           # code                                }else if(grade>=65){       elif grade>=65:
                 if(i>10)break         if i>10:                                 letter<-\"C+\"              letter=\"C+\"
                 i<-i+1                break                                 }else if(grade>=60){       elif grade>=60:
                }                      i+=1                                     letter<-\"C\"               letter=\"C\"    
                                                                             }else if(grade>=55{        elif grade>=55:
 6)            >plot(sin,-pi:pi)                                                letter<-\"C-\"               letter=\"C-\"    
               >plot(x,y)          >>>plt.plot(x,y)                          }else){                    else:
 7)            > hist()            >>>plt.hist(x)                               letter<-\"F\"                letter=\"F\"    
 8)            > pie(c(5,4,3))     >>>plt.pie([5,4,3])                       }
///////////////////////////////////////////
"

.compareP6<-"R packages and Python modules 
///////////////////////////////////////////
 Contents     R                     Python                               R                    Python  
 ----------  ----------            ------------------        -----------    ----------       ------
 1)install   >install.packages()    >>>pip install numpy     11) a string  >x=\"PV\"         >>>x=\"PV\"
                                                                           >y='rate\         >>>y='rate'
 2)load      >library(edgar)        >>>import math           10) upcase    >toupper('mary')  >>>'mary'upper()
             >require(edgar)        >>>import math as m      11) lowercase >tolower('Great') >>>\"Great\".lower()
                                    >>>from math import sqrt 12) logic or   ['abc']              ['abc']
                                    >>>from math import *                   ['a-z']              ['a-z']
                                                                           ['a-zA-Z']           ['a-zA-Z']  
 3)help      >help(package=edgar)   >>>print(dir(math))                     [0-9]                [0-9]
                                    >>>help(math.sqrt)        
 4)unload    >detach(edgar)         >>>del math               13)logic and  ('abc')              ('abc')

 5)Loaded    >search()                                        14) . (dot)    any object            any object
                                                              15) ?          0 or 1               0 or 1
 6)Installed >library()             >>>help(\"modules\")      16) +          1,2,3,..., n          1,2,3,..., n
    >.packages(all.available=T)     >>>pip list; #pip freeze  17) *          0,1,2,..., n          0,1,2,..., n
                                                              18) .*         anything              anything
 7)View      >install.packages('ctv')                         19)                                  (\\d)
             >library(ctv)
             >ctv::install.views('finance')
             >ctv::update.views('finance[')

 8)Search    http://r-project.org    http://pypi.org 
              -> loc -> list

 9) search   >.searchRpackages      >.searchPythonModules

10) manual   http://r-project.org   

///////////////////////////////////////////
"

