.preMidTerm<-function(i){
" i  Pre MidTerm
  -  -------------------------------------
  1  Chapters covered and how to prepare?
  2  Format of the mid-term 
  3  Prepare your own 'formula' sheet
  4  Submit a text or R script to the Dropbox on Canvas
  5  Part I:  Example #1
  .  ...
 19  Part II: Example #1
 20  Answers to MCs

 Example #1:> .preMidTerm  # see this instruction or list 

 Example #2:> .pmt         # the same as above (using a short-cut)

 Example #3:> .pmt(19)     # see the last one [Part II: Example #1]

 Example #4:> .pmt(20)     # Answers to MCs

";.preMidTerm_(i)}

.npreMidTerm<-20

.pmt<-.preMidTerm

.preMidTerm_<-function(i){
   if(i<=.npreMidTerm){
      .x<-paste('cat(.pmdP',i,')',sep='')
      .runText(.x)
   }else{
     p<-paste("Invalid number:\n   Input value should be between 1 and",.npreMidTerm)
     cat("\n",p," \n\n")
   }
}


.pmdP1<-"Chapters covered and how to prepare?
///////////////////////////////////////////
The mid-term would cover
------------------------
   Chapters: 1, 2,.. 9, and 11

How to prepare?
-------------
   1) Read lecture notes 
   2) Read those entries, such as .c1(2) 
   3) Watch a few related videos 
      .videos or .v 

   4) Try a few more end-of-chapter questions 
   5) Understand assigned homeworks 

   Date:  3/21, Monday
   Location: in the same classroom

///////////////////////////////////////////
"

.pmdP2<-"Format of the midTerm
/////////////////////////////////////
Part I: 15 to 20 multiple choice questions (one port each)
        including 1 to 3 debugging issues
---------------------------------
      please use the following format 
1,a
2,a
3,b
4,d
...
19,a
20,b

Part II:  (5 points each)
-------------------
      Question: usually 2 questions 
  
Weighting scheme. 
----------------
      50% for each part 

/////////////////////////////////////
"

.pmdP3<-"Prepare your own summary/formula sheet
/////////////////////////////////////
It is a good idea to have a summary (formula) sheet. 
You can write 
    1) formulae
    2) definitions
    3) examples
    4) sample code
    5) virtually anything
   Hand in  your sheet at the end of exam

 R cheat sheets
    https://rstudio.com/wp-content/uploads/2016/10/r-cheat-sheet-3.pdf
 RStudio cheat sheet
    https://rstudio.com/resources/cheatsheets/
 BasidR
    http://www.datasciencefree.com/basicR.pdf
 R cheat sheet
    http://web.mit.edu/hackl/www/lab/turkshop/slides/r-cheatsheet.pdf

//////////////////////////////////////
"
.pmdP4<-"Submit a text or R script to the Dropbox on Canvas
/////////////////////////////////////
For your text or R script file, it should be 

  firstName_lastName.txt 
         
          or 

  firstName_lastName.R
 
/////////////////////////////////////
"

.pmdP5<-"Part I: example #1
/////////////////////////////////////
  R is case sensitive. 

  a) True

  b) False 
 
/////////////////////////////////////
"

.pmdP6<-"Part I: example #2
/////////////////////////////////////

  Alignment is critical for R

   a)  True

   b)  False 

/////////////////////////////////////
"
.pmdP7<-"Part I: example #3
/////////////////////////////////////
  It is a good idea to use meaningful variable names. 

  a) True

  b) False

/////////////////////////////////////
"

.pmdP8<-"Part I: example #4 
///////////////////////////////////////////
  To list the files under the current working directory, we use

  a) ls()

  b) dir()

  c) rm()

  d) dir.create()

  e) None of the above   

/////////////////////////////////////
"

.pmdP9<-"Part I: example #5 
/////////////////////////////////////
  To delete a variable from our current working space, we use 
 
    a) ls()

    b) dir()

    c) rm()

    d) dir.create()

    e) None of the above   

/////////////////////////////////////
"

.pmdP10<-"Part I: example #6 
/////////////////////////////////////
  If we want to put several commands on the same line, 
     we can use one of the following separator to separate them. 

   a) ,   (comma)

   b) .   (period)

   c) ;   (semicolon)

   d) :   (colon)

   e)  None of the above 

/////////////////////////////////////
"

.pmdP11<-"Part I: example #7 
///////////////////////////////////////////
   To activate our code(program), we can use 
     one of the following functions. 

   a) dir()

   b) source()

   c) load()

   d) download.file()

   e) None of the above 

///////////////////////////////////////////
"
.pmdP12<-"Part I: example #8 
/////////////////////////////////////
   To load a remote R data set such as
        http://datayyy.com/data_R/ff3Monthly.RData
       we can use the following function(s)

  a)  load()

  b)  source()

  c)  load() and source()

  d)  load() and url()

  e)  None of the above 

/////////////////////////////////////
"

.pmdP13<-"Part I: example #9 
/////////////////////////////////////
  To find more information we can use

  a) source() function 

  b) help() function 

  c) download.file() function 

  d) rm() function 

/////////////////////////////////////
"

.pmdP14<-"Part I: example #10
///////////////////////////////////////////
  We can use notepad (Windows), textEdit (Mac) or 
     Microsoft Word to open R data sets. 

    a) True

    b) False 

///////////////////////////////////////////
"

.pmdP15<-"Part I: debugging example #1
///////////////////////////////////////////
    Debug the following code. 

  pv_f<-function(pv,r,n)fv/(1+r)^n
 
///////////////////////////////////////////
"

.pmdP16<-"Part I: debugging example #2
///////////////////////////////////////////
    Debug the following code. 

  pv_f<-function(pv,r,n)fv/(1+r)^n{
  \"Objective: calculate the present value
              for a given future value
        fv: future value
         r: discount rate
         n: number of periods
  \"
  }

///////////////////////////////////////////
"

.pmdP17<-"Part II: debugging example #3
///////////////////////////////////////////
    Debug the following code. 

    x<-read.csv(\"http://datayyy.com/data_R/ff3Monthly.RData')

///////////////////////////////////////////
"
.pmdP18<-"Part I: debugging example #4
///////////////////////////////////////////
    Debug the following code. 

   a<- 1:50
   b<- 2:100
   d<-cbind(a,b)
   x<-save(d,file='out.txt')
                                
///////////////////////////////////////////
"

.pmdP19<-"Part II: example #1
///////////////////////////////////////////
 Merge the IBM's monthly data with the Fama-French monthly 3-factor data

  IBM' monthly data: http://datayyy.com/data_csv/ibmMonthly.csv 

  Fama-French�s monthly data: http://datayyy.com/data_R/ff3Monthly.RData. 

///////////////////////////////////////////
"


.pmdP20<-"Answers to MC questions 
///////////////////////////////////////////

.pmt(5) Part I: example #1     a
.pmt(6) Part I: example #2     b
.pmt(7) Part I: example #3     a
.pmt(8) Part I: example #4     b
.pmt(9) Part I: example #5     c

.pmt(10) Part I: example #6    c
.pmt(11) Part I: example #7    b
.pmt(12) Part I: example #8    c
.pmt(13) Part I: example #9    b
.pmt(14) Part I: example #10   b

///////////////////////////////////////////
"


