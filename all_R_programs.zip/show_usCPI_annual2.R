.show_usCPI_annual<-function(n=2){
" Objective: show CPI annual CPI data
    n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs

     source: http://data.bls.gov/timeseries/CUSR0000SA0?output_view=pct_1mth  
     range : 1947 -2016

 Example 1: > .show_usCPI_annual()
               YEAR    CPI
             1 1947 0.0074
             2 1948 0.0030

 Example 2: > .show_usCPI_annual(-5)
               YEAR          CPI
            66 2012 0.0016363636
            67 2013 0.0012727273
            68 2014 0.0010000000
            69 2015 0.0006363636
            70 2016 0.0010000000

 Example 3: > x=.show_cpi_annual(0)


";.show_usCPI_annual_(n)
}

.show_usCPI_annual_<-function(n){


  if(exists('.usCPIannual')==FALSE) .load_yan("usCPIannual")

  .show_n_obs(.usCPIannual,n)


}
