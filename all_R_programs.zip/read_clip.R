.read_clip<-function(sep=""){
"Objective: read from the clipboard for both Windows and Mac

            Note: the method uses the 'clipr' R package. 
            install.packages('clipr')

  Example 1:> # copy something
            > x<-.read_clip()
  
  Example 2:> copy the data at
            >#  http://datayyy.com/data_txt/clipboard3.txt
            >  x<-.read_clip()
            >  dim(x)
              [1] 6 7
 
";.zread_clip_(sep)}

.rclip<<-.read_clip

.zread_clip_<-function(sep0){

   if("clipr" %in% .packages(all.available=T)){
        library(clipr)
        x<-clipr::read_clip_tbl(sep=sep0)
        return(x)
    }else{
         cat("Please install the 'clipr' R package\n")
         cat("   install.packages('clipr')\n")
   }

}


"
# https://stackoverflow.com/questions/14547069/how-to-write-from-r-to-the-clipboard-on-a-mac/44727345
Welcome to clipr. See ?write_clip for advisories on writing to the clipboard in R.
Error in chosen_write_clip(content, object_type, breaks, eos, return_new,  : 
  argument 'content' is missing, with no default
"