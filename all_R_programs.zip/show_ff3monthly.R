.show_ff3monthly<-function(n=2){
"Objective: show the Fama-French monthly 3 factors
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1:> .show_ff3monthly()
                      DATE MKT_RF    SMB     HML     RF
              1 1926-07-01 0.0296 -0.023 -0.0287 0.0022
              2 1926-08-01 0.0264 -0.014  0.0419 0.0025

 Example 2: > .show_ff3monthly(3)   # first 3
               DATE MKT_RF     SMB     HML     RF
          1 1926-07-01 0.0296 -0.0230 -0.0287 0.0022
          2 1926-08-01 0.0264 -0.0140  0.0419 0.0025
          3 1926-09-01 0.0036 -0.0132  0.0001 0.0023

 Example 3: > .show_ff3monthly(-2)  # last 2
                  DATE  MKT_RF    SMB     HML     RF
        1103 2018-05-01  0.0265 0.0524 -0.0313 0.0014
        1104 2018-06-01  0.0048 0.0115 -0.0241 0.0014

 Example 4:>.showff3monthly(0)     # get all 
             Launch Excel and paste

";.zshow_ff3monthly(n)}

.zshow_ff3monthly<-function(n){
   if(exists('.ff3monthly')==FALSE){
        .ff3Mdata<<-get(load(url('http://datayyy.com/data_R/ff3monthly.RData')))
   }
   .showNobs(.ff3Mdata,n)
}

