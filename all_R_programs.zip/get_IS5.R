.get_IS5<-function(ticker="ibm"){
"Objective: Get the Income Statement: IBM, WMT, AAPL, JNJ, or GM

 Example 1:> .get_IS5('ibm')  
              Window users: launch Excel and paste
      
";.zget_IS5(ticker)}

.zget_IS5<-function(ticker){
   if(exists('.IS5D')==FALSE){
      .IS5D<<-get(load(url("http://datayyy.com/getdata/is5.RData")))
   }
    
   ticker<-toupper(ticker)

   tickers<-unique(.IS5D$TICKER)

   a<-grep(ticker,tickers)
   if(length(a)==0){
      cat(' Ticker should be one of \n')
      print(tickers)
   }else{
       out<- .IS5D[grep(ticker,.IS5D$TICKER),]
       rownames(out)<-NULL
       .showNobs(out,0)
   }
}




