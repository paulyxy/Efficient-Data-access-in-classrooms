.readClipboardMac<-function(sep="\t",header=T){
"Objective: read data from a clipboard

  Step 1: open notepad or Excel to generate some data
  Step 2: copy the data
  Step 3: issue this function


 Example 1:># copy the following '5' lines [4 rows of observations plus an empty line]
            # try copy just 4 data lines to compare
x,y
1,4.5
2,3.3
5,10.23


          > x<-.readClipboardMac(sep=',')
          > dim(x)
            [1] 3 2 

 Example 2> copy the data at http://datayyy.com/data_txt/clipboard3.txt
          > x<-.readClipboardMac(sep='') 
          > dim(x)
            [1] 6 7            

";.zreadClipboardMac_(sep,header)}


.zreadClipboardMac_<-function(mySep,header){



    x<-read.table(pipe("pbpaste"), sep=mySep,header=header)
    return(x)

}