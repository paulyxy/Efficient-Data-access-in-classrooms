.show_sp500monthly<-function(n=2,type=0){
"Objective : show SP500 annual data 
       n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs
     type  : 0 for Windows
             1 for Mac
             2 for both
 
 Example 1:> .show_sp500monthly()
           DATE  OPEN  HIGH   LOW CLOSE ADJ.CLOSE VOLUME
   1 1927-12-01 17.66 17.66 17.66 17.66     17.66      0
   2 1928-01-01 17.76 17.76 17.26 17.57     17.57      0

 Example 2:> .show_sp500monthly(-2)

 Example 3:> .show_sp500monthly(0)
              Launch Excel and paste

 Example 4:> .show_sp500monthly(0,2)

";.show_sp500monthly_(n,type)}

.show_sp500monthly_<-function(n,type){
   if(exists('.sp500monthly')==FALSE){
      path<-"http://datayyy.com/data_R/sp500monthly.RData"
      load(url(path))
      .sp500monthly<<-.x
   }

   if(type==1){
           .show_n_obsMac(.sp500monthly,n)
   }else if(type==2){
         .show_n_obs(.sp500monthly,n)
   }else{
           .show_n_obsPC(.sp500monthly,n)
   }
}



