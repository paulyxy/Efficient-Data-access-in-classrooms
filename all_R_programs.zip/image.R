.image<-function(keyword_or_ID){
"Objective      : search ID for a code image
   keyword_or_ID:
                 Note that a 'png' R package is required
                 install.packages('png')

 Example 1>.image('')

";.zimage(keyword_or_ID)}


.images<<-.image

.zimage<-function(name){
     .path3<-"http://datayyy.com/getdata/images/"
     if(exists('.imageData')==FALSE){
          .tempPath<-paste0(.path3,"imageList",".RData")
          .imageData<<-get(load(url(.tempPath)))
     }

    if(typeof(name)=="character"){
          name<-toupper(name)
          out<-.imageData[grep(name,toupper(.imageData$NAME)),]
          rownames(out)<-NULL
          print(.leftAdj(out),row.names=F)

     #     print(.z6, row.names=F)
          
    }else{

       if("png" %in% .packages(all.available=T)){
         .showImage(name)

       }else{
           cat("Please install the 'png' R package\n")
           cat("   install.packages('png')\n")
       }
    }

}

