.show_usGDPquarterly<-function(n=2){
"Objective: show the US quarterly GDP
      n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs
      source : https://fred.stlouisfed.org/series/GDP 
      range  : 1947 ->
      Units  : Billions of Dollars,seasonally Adjusted Annual Rate

 Example 1: > .show_usGDPquarterly() # show the first two obs
                     DATE     GDP
             1 1947-01-01 243.164
             2 1947-04-01 245.968

 Example 2: > .gdpQ()              # same as the above

 Example 3: > .gdpQ(3)             # show the first 3 observations

 Example 4: > .gdpQ(-3)            # show the last three
                 DATE      GDP
       298 2021-04-01 22740.96
       299 2021-07-01 23202.34
       300 2021-10-01 23992.35

 Example 4:> .show_usGDPquarterly(0)
            Windows users: launch Excel and paste
                    or
            Mac users: launch Excel and paste

";.zshow_usGDPquarterly_(n)}

.gdpQ<<-.show_usGDPquarterly

.zshow_usGDPquarterly_<-function(n){
   if(exists('.usGDPqData')==FALSE){
     .usGDPqData<<-get(load(url("http://datayyy.com/data_R/GDPq.RData")))
   }

   .showNobs(.usGDPqData,n)
}



