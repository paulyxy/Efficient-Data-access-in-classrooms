
.cls<-function(){
"Objective: clear R consol
   Input  : none
   Example:
            >.cls()

"
   .cls_()

}

.cls_<-function() cat(rep("\n",50))

