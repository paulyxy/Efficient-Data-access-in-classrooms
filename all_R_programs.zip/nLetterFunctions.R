.nLetterFunctions<-function(n){
"Objective: show n-letter long functions

  Example #1: >.nLetterFunctions(3)

  Example #2: >.nLetterFunctions(20)

"
.nLetterFunctions_(n)}

.nLetterFunctions_<-function(.n){
   .x<-paste("^.{",.n,"}$",sep='')
   .y<-apropos(.x)
   .dot=substr(.y,1,1)=="."
   a<-.y[!.dot]
   return(a)
}

.nn<-.nLetterFunctions