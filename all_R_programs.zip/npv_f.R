.npv_f<-function(cashflow_vector,r){
"Objective        : estimate NPV (Net Present Value)
   cashflow_vector: 
        r         : discount rate
                   Note:the first cash flow at time 0

 Example 1:> a<-c(-100,20,20,40,50,20)
           > npv_f(a,0.1)
              [1] 11.33244

 Example 2:> .npv_f(100,0.1)
             [1] 100

 Example 3:> cash<-c(-100,110)
           > .npv_f(cash,0.1)
              [1] -1.421085e-14

";.npv_f_(cashflow_vector,r)}

.npv_f_<-function(cashflows,r){
   .pv_f<-function(fv,r,n)fv/(1+r)**n
   n<-length(cashflows)
   npv<-0
   for(i in 1:n){
      fv<-cashflows[i]
      pv<-.pv_f(fv,r,(i-1))
      npv<-npv + pv
   }
   return(npv)
}





