# assume that both ..week and ..course exist

.saveWeeklyWorkSpace<-function(){
   .t1<-"c://yan/teaching/getdata/"
   .t2<-paste(.t1,'R/w',..week,'.RData',sep='')
   base::save.image(.t2)
   cat("  File saved at\n  ", .t2, "\n")
}






