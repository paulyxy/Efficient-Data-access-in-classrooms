.pv_f<-function(fv,r,n){
"Objective: calculate the present value 
            for a given future value
                        fv
   Formula used: pv = --------------
                       (1+r)^n
      fv: a given future value
      r : period discount rate
      n : the number of periods

  Example #1: 

  Example #2: 

  Example #3: 

";.pv_f_(fv,r,n)}

.pv_f_<-function(fv,r,n){

   pv<-fv/(1+r)^n
   return(pv)
}


