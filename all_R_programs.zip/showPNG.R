.showPNG<-function(loc){
" Objective: show a picture 
    loc    : location for your PNG file[Note that the 'png' R package is required]
             library(png)

             If you receive the following error message
                Error in library(png) : there is no package called 'png'
             you should install it by issuing the following command
             install.packages('png')

 Example #1> # copy and paste the following two lines 
           infile<-'http://datayyy.com/images/fun.png'
           .showPNG(infile)

 Example #2> # copy-and-paste the following two lines 
           mac<-'http://datayyy.com/images/clipboardMac.png'
           .showPNG(mac)

 Example #3> # Assume that yo have a local file 
             infile<-'http://datayyy.com/images/financeCodeData.PNG'
            .showPNG(infile)

";.showPNG_(loc)}

.sp<-.showPNG

.showPNG_<-function(file){
  library(png)

  a<-grep("http",file)

  if(length(a)==0){
        graphics.off()
       .img <- readPNG(file)
       grid::grid.raster(.img)

  } else{
       .td = tempdir()                           #  create a temporary directory
       .tf = tempfile(tmpdir=.td, fileext=".png") # create the placeholder file
       download.file(file, .tf, quiet = TRUE,mode = 'wb')
       graphics.off()
       .img <- readPNG(.tf)
       grid::grid.raster(.img)
   }
}






