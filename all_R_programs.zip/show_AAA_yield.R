.show_AAA_yield<-function(n=2,freq=0){
"Objective: show the yield for Moody's AAA rated bonds
    n   : number of obs shown, n<0 from bottom 
    freq: frequency, 0 for daily, 1 for monthly 2 for annual (default is daily)

  Example 1:> show_AAA_yield()
            Date  Yield
         1 1983-01-03 0.1177
         2 1983-01-04 0.1179

  Exampel 2:> show_AAA_yield(-2)
                 Date  Yield

";.zshow_AAA_yield(n,freq)}


.zshow_AAA_yield<-function(n,freq){
    if(exists('moody_credit_yield')==FALSE) .load_yan("moody_credit_yield")   
    tt<-moody_AAA_yield_daily
    if(freq==1) {
           tt<-moody_AAA_yield_monthly 
    }else if(freq==2){
           tt<-moody_AAA_yield_annual
    }

    if(n>0){
            head(tt,n)
    } else{
           tail(tt,abs(n))
    }      
}

