
# ----------------------------------------------------- #
# --- US Debt annual    ------------------------------- #
# ----------------------------------------------------- #
# ----------------------------------------------------- #
# ----------------------------------------------------- #
.show_usDebt_annual<-function(n=2,dividedBy=1){
  "  Objective: show US natinal debt (annual)
            n : number of obs shownd, default value is 2
     dividedBy: scaling factor, such as 1e12

   range  : 1940 - 2015
   source : https://www.whitehouse.gov/omb/budget/Historicals
   unit   : million, 10^6
 
 Example 1: > .show_usDebt_annual()
                 YEAR  DEBT
               1 1940 50696
               2 1941 57531

 Example 2: > .show_usDebt_annual(-5)
                 YEAR     DEBT
               1 2011 14764222
               2 2012 16050921
               3 2013 16719434
               4 2014 17794483
               5 2015 18120106

 Example #3: > .show_usDebt_annual(-5,1e6)
                 YEAR     DEBT
               1 2011 14.76422
               2 2012 16.05092
               3 2013 16.71943
               4 2014 17.79448
               5 2015 18.12011

  ";.show_usDebt_annual_(n,dividedBy)
 }
.show_usDebt_annual_<-function(n,dividedBy){
   if(exists('.usDebt')==FALSE).load_yan("usDebt")
   .show_n_obs(.usDebt,n)
}


