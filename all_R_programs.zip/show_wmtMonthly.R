.show_wmtMonthly<-function(n=2){
"Objective: show WMT  monthly historical data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1:> .show_wmtMonthly()   

 Example 2:>.show_wmtMonthly(3)

 Example 3:>.show_wmtMonthly(-3)   # show the last 3 lines

 Example 4: > .show_wmtMonthly(0)  # get all to Excel
            # Launch Excel and paste
       
";.show_wmtMonthly_(n)}

.show_wmtMonthly_<-function(n){
   .path<-'http://datayyy.com/data_R/'
   .file<-'wmtMonthly.RData'
   if(exists('.wmtMonthly')==FALSE){
      infile<-paste0(.path,.file)
      .wmtMonthly<<-get(load(url(infile)))
   }
   .show_n_obs(.wmtMonthly,n)
}



