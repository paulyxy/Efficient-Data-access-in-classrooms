.rCode2pythonCode<-function(keyword){
"Objective: search 'equvalent' R and Python code 
  keyword : such as 'getwd'
                  
 Example #1:> .rCode2pythonCode(1)
       
  
";.rCode2pythonCode_(chapterOrName)}

.r2p<-.rCode2pythonCode

.rCode2pythonCode_<-function(nOrName){
     .path3<-"http://datayyy.com/data_R/"

     if(exists('.code100')==FALSE){
           .tempPath<-paste0(.path3,"code100",".RData")
           load(url(.tempPath))
           .code100<<-.x
      }

      if(typeof(nOrName)=="double"){
         if(nOrName<10){
            nOrName<-paste0('c0',nOrName,"_")
         }else{
            nOrName<-paste0('c',nOrName,"_")
         }
      }

      .a<-toupper(nOrName)
      .b<-toupper(.code100$NAME)
      .z<-.code100[grep(.a,.b),]
      .z2<-format(.z, justify = "left")
      # rownames(.z2)<-NULL
      rownames(.z2)<-NULL
      return(.leftAdj(.z2))
}

