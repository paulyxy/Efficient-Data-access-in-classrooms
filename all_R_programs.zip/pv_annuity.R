.pv_annuity<-function(c,r,n){
" add an explanation here 

";.pv_annuity_(c,r,n)}

.pv_annuity_<-function(c,r,n){

  if(r!=0){
      temp1<-c/r
      temp2<-1-1/(1+r)^n
      pv<-temp1*temp2
      return(pv)
  }else{
     cat("My error message: r should not be zero \n")

  }
}


