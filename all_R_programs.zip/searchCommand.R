.searchCommand<-function(keyword){
"Objective: search and compare commands (R vs. Python)

 Example #1:> .searchCommand('yahoo')

 Example #2:>.sw('yahoo')      # same as above

 Example #3> .sw('census')
  
";.searchCommand_(keyword)}

.searchCommand_<-function(keyword){
     .path3<-"http://datayyy.com/data_R/"

     if(exists('.commands')==FALSE){
           .tempPath<-paste0(.path3,"commandRvsPython",".RData")
           load(url(.tempPath))
           .commands<<-.x
      }

      .a<-toupper(keyword)
      .b<-toupper(.commands$R_COMMAND)
      .b2<-toupper(.commands$PYTHON_COMMAND)

      .z<-grep(.a,.b)
      .z2<-grep(.a,.b2)
      .z3<-c(.z,.z2)
     .z4<-unique(.z3)

#      .z<-.websites[grep(.a,.b),]
#      .z2<-.websites[grep(.a,.b2),]

      .z5<-.commands[.z4,]
      .z6<-format(.z5, justify = "left")

      rownames(.z6)<-NULL
      #cat(.z6)
     return(.leftAdj(.z6))

 a4<-.z6$R_COMMAND
 b1<-.z6$PYTHON_COMMAND
 b2<-strsplit(b1,"\n")
 n<-length(b2[[1]])

 b4<-b2[[1]][1]
 for(i in 2:n){
   b4<-rbind(b4,b2[[1]][i])
   a4<-rbind(a4,"  ")
  }

 final<-data.frame(a4,b4)
 colnames(final)<-colnames(.z6)
 final2<-na.omit(final)

 colnames(final2)<-NULL
 return(final2)
}

