.merge<-function(){
"Objective: By date, merge two data sets copied from Excel, 
            then copy the merged result back to Excel 
          : no input value

 Example #1: .merge()

DATE	data1
1	10
2	2
3	4

DATE	data2
2	3.3
3	5.3
4	1.23
5	-9.2

";.merge_()}

.merge_<-function(){
 cat('\n   Copy the 1st data set from Excel\n')
 cat('        then hit the Enter-key\n   ')
 readline()

 df0<-read.table("clipboard",header=T)
 cat("The head of the data set:\n")
 print(head(df0))

 dd<-as.Date(df0[,1],format="%m/%d/%Y")
 m<-ncol(df0)
 dd<-as.Date(df0[,1],format="%m/%d/%Y")
 df1<-data.frame(dd,df0[,2:m])
 colnames(df1)<-toupper(colnames(df0))


 cat('\n   Copy the 2nd data set from Excel\n')
 cat('         then hit the Enter-key\n   ')
 readline()

 df0<-read.table("clipboard",header=T)
 cat("The head of the data set:\n")
 print(head(df0))

 dd<-as.Date(df0[,1],format="%m/%d/%Y")
 m<-ncol(df0)
 dd<-as.Date(df0[,1],format="%m/%d/%Y")
 df2<-data.frame(dd,df0[,2:m])
 colnames(df2)<-toupper(colnames(df0))

 df3<-merge(df1,df2)

 #a<-intersect(colnames(df1),colnames(df2))
# df4<-df3[order(df3[a]),]   # sort by date 

 write.table(df3,file="clipboard",row.names=F,quote=F,sep="\t")
 cat('\n Paste the merged result to Excel\n') 
}

