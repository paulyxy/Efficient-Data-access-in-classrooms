.one<-function(){
"

 Copy the following line to your R console
     source('http://datayyy.com/getexam.txt') 

";.one_()}


.one_<-function(){
cat("

 Copy the following line to your R console
    source('http://datayyy.com/getexam.txt') 

")
}

