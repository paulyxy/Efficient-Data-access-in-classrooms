.show_ibmMonthlyMac<-function(n=2){
"Objective: show Fama-French 3 monthly factors
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations
   format  : 1 (default value) for Excel  .show_ibmMonthlyMac(0)
             2 or other value  for R      .show_ibmMonthlyMac(0,2)


 Example 1:> .show_ibmMonthlyMac()   
                   DATE     OPEN     HIGH      LOW    CLOSE ADJ.CLOSE  VOLUME
           1 1962-01-01 7.713333 7.713333 7.003334 7.226666  1.889625 8760000
           2 1962-02-01 7.300000 7.480000 7.093333 7.160000  1.872192 5737600

 Example 2:>.show_ibmMonthlyMac(1)
                  DATE     OPEN     HIGH      LOW    CLOSE ADJ.CLOSE  VOLUME
          1 1962-01-01 7.713333 7.713333 7.003334 7.226666  1.889625 8760000

 Example 3:>.show_ibmMonthlyMac(-2)   # show the last 2 lines
                   DATE   OPEN   HIGH    LOW  CLOSE ADJ.CLOSE   VOLUME
         690 2019-06-01 127.10 140.15 127.06 137.90  137.9000 61341600
         691 2019-07-01 139.60 141.49 139.28 139.88  139.8800  3377700

 Example 4: > .show_ibmMonthlyMac(0)  # get all to Excel
               Launch Excel and paste
       

";.show_ibmMonthlyMac_(n)}

.show_ibmMonthlyMac_<-function(n){
   if(exists('.ibmMonthly')==FALSE){
      .ibmMonthly<<-get(load(url("http://datayyy.com/data_R/ibmMonthly.RData")))
   }

        if(n!=0){
           .show_n_obs(.ibmMonthly,n)
        }else{
            clip <- pipe("pbcopy", "w")    
            write.table(.ibmMonthly, file=clip,quote=F,row.names=F,sep=",")                               
            close(clip)
            cat('  Mac users: launch Excel and paste \n')
       }

}

