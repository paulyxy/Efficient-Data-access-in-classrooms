.searchCensusVar<-function(keyword,data=-9){
"Objective: find Name, label or concepts

 Example #1:> .searchCensusVar('H001001')
               DATA VARIABLE LABEL       CONCEPT
             1  sf1  H001001 Total HOUSING UNITS

 Example #2:>.searchCensusVar('p001001')
               DATA    NAME LABEL          CONCEPT
             1  sf1 P001001 Total TOTAL POPULATION

 Example #3:>a<-.searchCensusVar('population')
            > dim(a)  # [1] 252872      4
            >b<-.searchCensusVar('occupied housing ',a)
            > dim(b)  # [1] 2253    4
            > head(b)
      DATA     NAME                                                                       LABEL
    1  sf1  H011001                                  Total population in occupied housing units
    2  sf1  H011002 Total population in occupied housing units!!Owned with a mortgage or a loan
    3  sf1  H011003            Total population in occupied housing units!!Owned free and clear
    4  sf1  H011004                 Total population in occupied housing units!!Renter occupied
    5  sf1 H011A001                                        Population in occupied housing units
    6  sf1 H011A002       Population in occupied housing units!!Owned with a mortgage or a loan
                                                                            CONCEPT
    1                           TOTAL POPULATION IN OCCUPIED HOUSING UNITS BY TENURE
    2                           TOTAL POPULATION IN OCCUPIED HOUSING UNITS BY TENURE
    3                           TOTAL POPULATION IN OCCUPIED HOUSING UNITS BY TENURE
    4                           TOTAL POPULATION IN OCCUPIED HOUSING UNITS BY TENURE
    5 TOTAL POPULATION IN OCCUPIED HOUSING UNITS BY TENURE (WHITE ALONE HOUSEHOLDER)
    6 TOTAL POPULATION IN OCCUPIED HOUSING UNITS BY TENURE (WHITE ALONE HOUSEHOLDER)

";.searchCensusVar_(keyword,data)}

.searchCensusVar_<-function(keyword,data){
    .path<-"http://datayyy.com/data_R/"

    if(exists('.censesVars')==FALSE){
          .tempPath<-paste0(.path,"censusVars",".RData")
          .censusVars<-get(load(url(.tempPath)))
    }

    if(data==-9){
          .x<-.censusVars
    }else{
          .x<-data
     }
     #keyword<-'h001001'
     a<-grep(toupper(keyword),toupper(.x$DATA))
     b<-grep(toupper(keyword),toupper(.x$NAME))
     d<-grep(toupper(keyword),toupper(.x$LABEL))
     e<-grep(toupper(keyword),toupper(.x$CONCEPT))
 
     f<-unique(c(a,b,d,e))
   
    output<-data.frame(.x[f,])
    rownames(output)<- NULL
    return(output)
}






