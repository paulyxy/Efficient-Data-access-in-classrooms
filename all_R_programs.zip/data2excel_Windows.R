.data2excel_Windows<-function(keyword_or_ID){
"Objective      : keyword or ID
   keyword_or_ID: such as 'c1_', 'c5_', 12, 44
                  Note: assume that the 'clipr' package is installed. 
                  install.packages('clipr')
          
 Example 1>.data2excel_Windows('c1_') # all images for chapter 1
 
 Example 2>.d2('c1_')   # same as the above 
 
 Example 3>.d3('GDP')

";.zdata2excel_Windows_(keyword_or_ID)}

.d2<<-.data2excel_Windows
.data2Excel_Windows<<-.data2excel_Windows

.zdata2excel_Windows_<-function(name){
     .path3<-"http://datayyy.com/if/data/"
     if(exists('.ifData')==FALSE){
          .tempPath<-paste0(.path3,"ifData",".RData")
          .ifData<<-get(load(url(.tempPath)))
     }

     if(typeof(name)=="character"){
          name<-toupper(name)
          out<-.ifData[grep(name,toupper(.ifData$NAME)),]
          rownames(out)<-NULL
          print(.leftAdj(out))
          
    }else{
         name2<-.ifData$NAME[name]
         infile<-paste0(.path3,name2,".csv")
         .x<-read.csv(infile)
         .write_clip(.x)
         cat("  For both Windows and Mac users:\n")
         cat("      Launch Excel and paste! \n")
    }
}


