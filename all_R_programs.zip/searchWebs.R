.searchWebs<-function(keyword_or_ID){
"Objective: search web links for a given keyword

 Example #1:> .searchWebs('speech')
            ID                         NAME                                   WEBSITE
             1 Obama 2008 speech             http://datayyy.com/doc_txt/obama2008.txt 
             2 Trump 2018 acceptance speech  http://datayyy.com/doc_txt/trump2016.txt 
             3 Reagan 1964 speech            http://datayyy.com/doc_txt/reagan1964.txt

 Example #2:>.sw('speech')   # .sw() is the short-cut of .searchWebs()

 Example #3> .sw(1)          # go to the web page

 
";.zsearchWebs(keyword_or_ID)}

.sw<-.searchWebs

.zsearchWebs<-function(keyword){

     .path3<-"http://datayyy.com/getdata/"
     if(exists('.websites')==FALSE){
           .tempPath<-paste0(.path3,"websites",".RData")
           x<-get(load(url(.tempPath)))
           x2<-data.frame(1:nrow(x),x)
           colnames(x2)<-c("ID","NAME","WEBSITE")
           .websites<<-x2
      }

      if(is.character(keyword)==TRUE){
            .x<-.websites
            a<-strsplit(keyword," ")[[1]]
           .a<-toupper(gsub(" ","",keyword))
           .b<-toupper(gsub(" ","",.x$NAME))
           .b2<-toupper(gsub(" ","",.x$WEBSITE))
           .z<-grep(.a,.b)
           .z2<-grep(.a,.b2)
           .z3<-c(.z,.z2)
           .z4<-unique(.z3)
           .z5<-.websites[.z4,]
           .z5$WEBSITE<-gsub(";",",",.z5$WEBSITE)
           .z6<-format(.z5, justify = "left")
            rownames(.z6)<-NULL

           # cat(".z3",.z3,'\n')
 
           if(length(a)==1){
                print(.z6, row.names=F)
           }else{
               t<-paste0(a,collapse=" ")
               t2<-sub(" ",".*",t)
    #           cat('t2=',t2,"\n")
              .a<-toupper(gsub(" ","",t2))
              .b<-toupper(gsub(" ","",.x$NAME))
              .b2<-toupper(gsub(" ","",.x$WEBSITE))
              .z<-grep(.a,.b)
              .z2<-grep(.a,.b2)
              .z3<-c(.z,.z2)

              
               t<-paste0(rev(a),collapse=" ")
               t2<-sub(" ",".*",t)
 #             cat('t2=',t2,"\n")
              .a<-toupper(gsub(" ","",t2))
              .b<-toupper(gsub(" ","",.x$NAME))
              .b2<-toupper(gsub(" ","",.x$WEBSITE))
              .z<-grep(.a,.b)
              .z2<-grep(.a,.b2)
    
               .z33<<-c(.z,.z2,.z3)
               .z4<-unique(.z33)
               .z5<-.getdataWebs[.z4,]
               .z5$WEBSITE<-gsub(";",",",.z5$WEBSITE)
               .z6<-format(.z5, justify = "left")
                rownames(.z6)<-NULL
                print(.z6, row.names=F)
          }
    }else{
      .showWebs(keyword)
    }
}
 
