.copyNobs2t.txt<-function(loc,n,outfile='t.xt'){
"Objective: copy the first n observation to t.txt 
   loc    : location
   n      : the fisrst n observation 
            if n< 0  copy from the bottum
  outfile : default is t.txt

 Example #1: infile<-'http://datayyy.com/data_txt/F-F_Research_Data_Factors.txt'
             .copyNobs2t.txt(infile,20)

";.copyNobs2t.txt_(loc,n,outfile)}

.copyNobs2t.txt_<-function(loc,n,outfile){
   a<-readLines(loc)
   if(n>0){
          b<-head(a,n)
          write(b,outfile)
    }else{



    }

    cat("You can issue the following line to show it\n")
    cat("     print(readLines('t.txt'),quote=F)    \n")
}

.c2t <-.copyNobs2t.txt