.show_sp500daily<-function(n=2,type=0){
"Objective : show SP500 annual data 
       n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs
     type  : 0 for Windows
             1 for Mac
             2 for both
 
 Example 1:> .show_sp500daily()

 Example 2:> .show_sp500daily(-2)

 Example 3:> .show_sp500daily(0)
              Launch Excel and paste

 Example 4:> .show_sp500daily(0,2)

";.show_sp500daily_(n,type)}

.show_sp500daily_<-function(n,type){
   if(exists('.sp500daily')==FALSE){
      path<-"http://datayyy.com/data_R/sp500daily.RData"
      load(url(path))
      .sp500daily<<-.x
   }

   if(type==1){
           .show_n_obsMac(.sp500daily,n)
   }else if(type==2){
         .show_n_obs(.sp500daily,n)
   }else{
           .show_n_obsPC(.sp500daily,n)
   }
}



