.showFirstNameGirls<-function(n=2){
"Objective: show 1000 most popular girl's names 
      n   : number of names to show
            n>0 from the beginning
            n<0 from the end
            n=0 copy all names to Excel 
            The default value of n is 2

 Example 1:> .showFirstNameGirls()
              NAME
           1   Emma
           2 Olivia

 Example 2: > .showFirstNameGirls(4)
               NAME
         1     Emma
         2   Olivia
         3      Ava
         4 Isabella

 Example 3: > .girl(-4)
              NAME
    997       Miya
    998  Monserrat
    999    Zendaya
    1000     Alora
 
 Example 4: > .girl(0)
           Launch Excel and paste

";.showFirstNameGirls_(n)}

.girl<-.showFirstNameGirls

.showFirstNameGirls_<-function(n){
   if(exists('.girlNames')==FALSE){
       load(url("http://datayyy.com/data_R/top1000girlNames.RData"))
       .girlNames<<-.x
   }
   .show_n_obs(.girlNames,n)
}



