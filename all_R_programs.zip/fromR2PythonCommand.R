.fromR2PythonCommand<-function(fun){
"Objective: for a give funciton name such as getwd
            find a equivalent Python command
   function: 

 Example #1:

";.fromR2PythonCommand_(fun)}



.fromR2PythonCommand_<-function(fun){

}



