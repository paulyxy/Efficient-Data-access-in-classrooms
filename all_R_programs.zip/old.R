.old<-function(){
"Q3: 7.26 Annuity is defined as: the same cash flows happen at the same interval 
         for n periods. A few examples are shown below. 
 Example #1          c    c    c    c
      |----|----|----|----|... |----|
      0    1    2    3    4    19  20
 Example #2: 
           c    c    c    c    c 
      |----|----|----|... |----|
      0    1    2    3    n-1  n
 Example #3: A general one 
                          c    c     c    c
      |----|----|----|... |----| ... |----|
      0    1    2    3    k   k+1   k+n-2  k+n-1

Assume that all those cash flows occur at the end of each period and the first 
    cash flow occurs   at the end of the first period (example #2), we have the
    following formula to estimate a future  value. 
                        c          1
       fv(annuity) =   --- [1 -   ----     ]                     (1)
                        R        (1+R)^n
  What is the future value, if a person saves $500 at the end of each year for 40 
       years? Assume that the annual discount rate of 5% and the first cash flow 
       happens at the end of the first year. 
    1) Write an R function for the above equation.
    2) Use at least two types of loops to calculate the future value.
    3) What is the future value if the first cash flow happens at the end of year 5?

";.old_()}




.old_<-function(){
cat("

Q3: 7.26 Annuity is defined as: the same cash flows happen at the same interval 
         for n periods. A few examples are shown below. 
 Example #1          c    c    c    c
      |----|----|----|----|... |----|
      0    1    2    3    4    19  20
 Example #2: 
           c    c    c    c    c 
      |----|----|----|... |----|
      0    1    2    3    n-1  n
 Example #3: A general one 
                          c    c     c    c
      |----|----|----|... |----| ... |----|
      0    1    2    3    k   k+1   k+n-2  k+n-1

Assume that all those cash flows occur at the end of each period and the first 
    cash flow occurs   at the end of the first period (example #2), we have the
    following formula to estimate a future  value. 
                        c          1
       fv(annuity) =   --- [1 -   ----     ]                     (1)
                        R        (1+R)^n
  What is the future value, if a person saves $500 at the end of each year for 40 
       years? Assume that the annual discount rate of 5% and the first cash flow 
       happens at the end of the first year. 
    1) Write an R function for the above equation.
    2) Use at least two types of loops to calculate the future value.
    3) What is the future value if the first cash flow happens at the end of year 5?

")}

