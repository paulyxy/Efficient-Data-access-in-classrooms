.show_ff3daily<-function(n=2){
" Objective: show Fama-French daily 3 factors
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

   range     : 7/1/1926 to 5/31/2016
   source    : http://mba.tuck.dartmouth.edu/pages/faculty/ken.french/data_library.html
   frequency : daily 

 Example 1: > .show_ff3daily()
                 DATE MKT_RF     SMB     HML    RF
            1 1926-07-01 0.0010 -0.0024 -0.0028 9e-05
            2 1926-07-02 0.0045 -0.0032 -0.0008 9e-05

 Example 2: > .show_ff3daily(-5)

 Example 3:> x=.show_ff3daily(0)
           > save_data(x,'c:/temp/ff3daily.csv')
            [1] 'Your saved file is ==>c:/temp/ffdaily.csv'

";.zshow_ff3daily(n)}

.zshow_ff3daily<-function(n){
   if(exists('.ff3ddata')==FALSE){
      .ff3ddata<<-get(load(url('http://datayyy.com/data_R/ff3daily.RData')))
    }
   .show_n_obs(.ff3ddata,n)
}

