# search fake data 

.searchData<-function(keyword_or_ID){
"Objectives: 1) find ID(s) by using a keyword
             2) load a data set to Excel by entering its ID
 kewword_or_ID: input variable 

 Example #1: > .searchData('c1_')    # for chapter 1
           ID                     NAME2
            1 c1_%5egspcDaily.csv      
            2 c1_%5egspcMonthly.csv    
            3 c1_1_CensusData_2010a.csv
            4 c1_aaplBS.txt            
            5 c1_aaplCF.txt            
            6 c1_aaplDaily.csv        
      
 Example #2:>.searchData('sp500mon')
            ID                   NAME2
           234 c30_ibmSP500monthly.csv
           235 c30_ibmSP500monthly.txt
           273 c30_sp500monthly.csv   
           274 c30_sp500Monthly.csv   
           275 c30_sp500monthly.txt   
    
 Example #3:> .searchData(273)
             Windows users: launch Excel and paste
               or 
             Mac users: launch Excel and paste 

";.zsearchData(keyword_or_ID)}

.zsearchData<-function(chapterOrName){

     if(exists('.fakeData')==FALSE){
       .tempPath<-'http://datayyy.com/data_R/fakeData.RData'
       .fakeData<<-get(load(url(.tempPath)))
      }
      n<-nrow(.fakeData)
       
   if(typeof(chapterOrName)=="double"){
        if(chapterOrName<1 | chapterOrName>n){
            cat("  Error message: chapter should be between 1 and ",n,"\n")
        }else{

        a<-grep(".csv",.fakeData$NAME2[chapterOrName])
        if(length(a)==0){
             path<-'http://datayyy.com/data_txt/'
             infile<-paste0(path,.fakeData$NAME2[chapterOrName])
             x<-readLines(infile)
        }else{
            path<-'http://datayyy.com/data_csv/'
            infile<-paste0(path,.fakeData$NAME2[chapterOrName])
            x<-read.csv(infile)
        }
         .showNobs(x,0)  

        }
    }else{
      .a<-tolower(chapterOrName)
      .b<-tolower(.fakeData$NAME2)
      #.z<-.fakeData$NAME1[grep(.a,.b)]
      .z<-.fakeData[grep(.a,.b),][,c(1,3)]

      #rownames(.z)<-NULL
      print(.leftAdj(.z),row.names=F)
   }
}








