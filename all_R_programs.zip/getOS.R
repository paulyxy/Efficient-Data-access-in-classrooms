# https://conjugateprior.org/2015/06/identifying-the-os-from-r/
# a<-.getOS()     a=="windows"   
#                 a=="osx"

.getOS<- function(){

  sysinf <- Sys.info()
  if (!is.null(sysinf)){
      os <- sysinf['sysname']
      if (os == 'Darwin')
       os <- "osx"
  } else { ## mystery machine
        os <- .Platform$OS.type
      if (grepl("^darwin", R.version$os))
         os <- "osx"
       if (grepl("linux-gnu", R.version$os))
         os <- "linux"
  }
 
  final<-tolower(os)
  return(final)
}