.show_secIndex<-function(n=2,y=1995,q=1){
"Objective : SEC 2020Q1 index 
       n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs

 Example 1:> .show_secIndex()

 Example 2:> .show_secIndex(-2)

 Example 3:> .show_secIndex(0)
              Launch Excel and paste

";.show_secIndex_(n,y,q)}

.show_secIndex_<-function(n,y,q){
     
    infile=paste0("https://www.sec.gov/Archives/edgar/full-index/",y,"/QTR",q,"/company.idx")
   .x<-readLines(infile)

   .show_n_obs(.x,n)
}

