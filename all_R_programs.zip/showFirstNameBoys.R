.showFirstNameBoys<-function(n=2){
"Objective: show 1000 most popular boy's names 
      n   : number of names to show
            n>0 from the beginning
            n<0 from the end
            n=0 copy all names to Excel 
            The default value of n is 2

 Example 1:> .showFirstNameBoys()
                NAME
             1 Liam
             2 Noah

 Example 2: > .boy(-3)
                    NAME
            998  Yisroel
            999   Howard
            1000    Jaxx

 Example 3: > .boy(0)
              Launch Excel and paste

";.showFirstNameBoys_(n)}

.boy<-.showFirstNameBoys

.showFirstNameBoys_<-function(n){
   if(exists('.boyNames')==FALSE){
       load(url("http://datayyy.com/data_R/top1000boyNames.RData"))
       .boyNames<<-.x
   }
   .show_n_obs(.boyNames,n)
}


