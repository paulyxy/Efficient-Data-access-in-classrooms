.search<-function(nOrName=2,data=-9){
"Objective: find the DATA_ID for a specific data set 
   nOrName  : nOrName such as 2 or 'txt'
   data     : defaul will be our index file
              output can be an input, see below  

 Example #1: > .search()
 
 Example #2: > .search(3)
 
 Example #3: > .search(-2)
 
 Example #4: a=.search('csv')
 
 Example #5: > search twice 
            a<-.search('rdata')
            dim(a)   # [1] 192   2
           .search('torq',a)
 
 Example #6: any place vs. at the end
 
";.search_(nOrName,data)}

.search_<-function(nOrName,data){
    if(length(data)==1){
        .path3<-"http://datayyy.com/sas/"
        if(exists('.data521')==FALSE){
              .tempPath<-paste(.path3,"data521",".RData",sep='')
              load(url(.tempPath))
              #load(.tempPath)
              .data521<<-.x
              data<-.x
        }else{
             data<-.data521
        }
      }

      if(typeof(nOrName)=="double"){
            .show_n_obs(data,nOrName)
       }else{
          .a<-toupper(nOrName)
          .b<-toupper(data$NAME)
          .z<-data[grep(.a,.b),]
          .z2<-format(.z, justify = "left")
          # rownames(.z2)<-NULL
          return(.z2)
       }
}



