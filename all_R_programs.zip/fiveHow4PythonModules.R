.fiveHow4PythonModules<-function(data_ID){
"Objective: Five How's for Python modules 

  1) How to unpload a Phthon module?
      import pandas as pd

  2) How to list all functions inside a module? 
      import pandas as pd
      print(dir(pd))

  3) How to find info for a given function? 
      import pandas as pd
      help(pd.read_pickle)
     
  4) How to install the 'download' Python module?
       pip install download 

  5) How to search useful Python modules?
       http://pypi.org 

     [Note that 'pypi' stands for Python Package Index]

 Example #1:> .fiveHow4PythonModules()

 Example #2:> .fh()
   
";.fiveHow4PythonModules_(data_ID)}

.fh<-.fiveHow4PythonModules
.fiveHow4PythonModules_<-function(i){
cat("Objective: Five How's for Python modules 

  1) How to unpload a Phthon module?
      import pandas as pd

  2) How to list all functions inside a module? 
      import pandas as pd
      print(dir(pd))

  3) How to find info for a given function? 
      import pandas as pd
      help(pd.read_pickle)
     
  4) How to install the 'download' Python module?
       pip install download 

  5) How to search useful Python modules?
       http://pypi.org 

     [Note that 'pypi' stands for Python Package Index]
")}



