.load_yan<-function(name){
   "Objective: load an R data set from http://datayyy.com/data_R/
     e.g., 
            To load sec10k1993_20130906.RData
            >.load_yan('sec10k1993_20130906')




"; .load_yan_(name)}

.load_yan_<-function(name){
     #print(name)
     if(name=='sec10k'){
         name='sec10k1993_20130906'
     }

     ..pathRData<-"http://datayyy.com/data_R/"
     #print(t1)

     t2<-paste(..pathRData,name,'.RData',sep='')
     con<-url(t2)
     #print(t2)

     load(con)
     close(con)

     if(name=='stockMonthly.RData'){
            stockMonthly<<-stockMonthly 

     }else if(name=='name_cik'){
          name_cik<<-name_cik 

     # ----- add here -------------------

        }else if(name=='benford'){
             .benfordData<<-.x

        }else if(name=='sharesOutstanding'){
             .sharesOutstanding<<-.x

      }else if(name=='formulae'){
             .formulae<<-.x

      }else if(name=='sp500addedDeleted'){
             .sp500addedDeleted<<-.x

      }else if(name=='allRpackages'){
             .allRpackages<<-.x

      }else if(name=='titanic'){
             .titanic<<-.x

    }else if(name=='ff3_ibmMonthly'){
          .ff3_ibmMonthly<<-.x

     }else if(name=='sp500annual'){
          .sp500annual<<-.x

     }else if(name=='rosco'){
          .rosco<<-.x

     }else if(name=='fogIndex1994_2011'){
          .fogIndex<<-.x

     }else if(name=='positiveWords'){
          .positiveWords<<-.x

     }else if(name=='negativeWords'){
          .negativeWords<<-.x

     }else if(name=='finalExam2'){
          .finalExam<<-.x


     }else if(name=='hsicDaily'){
          .hsicDaily<<-.x

     }else if(name=='chickEgg'){
          .chickEgg<<-.x

     }else if(name=='putCallRatio'){
          .putCallRatio<<-.x



     }else if(name=='bondSpread'){
          .bondSpread<<-.x

     }else if(name=='DTAQtrade50'){
          .DTAQtrade50<<-.x



     }else if(name=='ibmMonthly'){
          .ibmMonthly<<-.x

     }else if(name=='wmtMonthly'){
          .wmtMonthly<<-.x



     }else if(name=='populationGDP2019'){
          .populationGDP2019<<-.x

     }else if(name=='sp500monthly'){
          .sp500monthly<<-.x

     }else if(name=='sp500daily'){
          .sp500daily<<-.x

     }else if(name=='fail2deliver201810a'){
          .fail2deliver201810a<<-.x

    }else if(name=='economicFreedomIndex'){
          .economicFreedomIndex<<-.economicFreedomIndex


    }else if(name=='vix'){
          .vix<<-.vix


     }else if(name=='cikticker'){
          .cikticker<<-.cikticker

     }else if(name=='ff10VWindustryMonthly'){
          .ff10VWindustryMonthly<<-.ff10VWindustryMonthly


     }else if(name=='ff5industryVW'){
          .ff5industryVW<<-.x
     }else if(name=='ff5industryEW'){
          .ff5industryEW<<-.x


     }else if(name=='ibmDaily'){
          .ibmDaily<<-.x

     }else if(name=='marketCap'){
          .marketCap<<-.x

     }else if(name=='tradingDaysDaily'){
          .tradingDaysDaily<<-.tradingDaysDaily


     }else if(name=='tradingDaysMonthly'){
          .tradingDaysMonthly<<-.tradingDaysMonthly


     }else if(name=='ff3Monthly'){
          .ff3Monthly<<-.x
     }else if(name=='ff3Daily'){
          .ff3Daily<<-.x

     }else if(name=='ffc4Monthly'){
          .ffc4Monthly<<-.ffc4Monthly
     }else if(name=='ffc4Daily'){
          .ffc4Daily<<-.ffc4Daily


     }else if(name=='ff5Monthly'){
          .ff5Monthly<<-.ff5Monthly
     }else if(name=='ff5Daily'){
          .ff5Daily<<-.ff5Daily

     }else if(name=='ff5EWindustry'){
          .ff5EWindustry<<-.x

     }else if(name=='ff5VWindustry'){
          .ff5VWindustry<<-.x

     }else if(name=='ct1day'){
          .ct1day<<-.ct1day 
     }else if(name=='cq1day'){
          .cq1day<<-.cq1day 


     }else if(name=='TORQct'){
          .TORQct<<-.TORQct
     }else if(name=='TORQcq'){
          .TORQcq<<-.TORQcq 


     }else if(name=='ffMonthly'){
          .ffMonthly<<-.ffMonthly

    }else if(name=='stock11monthly'){
          .stock11monthly<<-.stock11monthly


     }else if(name=='dollarIndex'){
          .dollarIndex<<-.dollarIndex 

     }else if(name=='qq2'){
          .qq2<<-.qq2 

     }else if(name=='creditSpread'){
          .creditSpread<<-.x 

     }else if(name=='nyseListing'){
          .nyseListing<<-.nyseListing 


     }else if(name=='fedFundRate'){
          .fedFundRate<<-.x 


     }else if(name=='euroDollarDeposit1m'){
          .euroDollarDeposit1m<<-.euroDollarDeposit1m 


     }else if(name=='indexDaily'){
          .indexDaily<<-.indexDaily 

     }else if(name=='sec10k1993_20130906'){
          .sec10k1993_20130906<<-.sec10k1993_20130906 
    
     }else if(name=='ff'){
          .ff_daily_factors<<-.ff_daily_factors
          .ff_monthly_factors<<-.ff_monthly_factors

     }else if(name=='ff_daily_factors'){
          .ff_daily_factors<<-.ff_daily_factors

     }else if(name=='ff_monthly_factors'){
          .ff_monthly_factors<<-.ff_monthly_factors

     }else if(name=='cik'){
          .cik<<-.cik

     }else if(name=='sec10k'){
          .sec10k1993_20130906<<-.sec10k1993_20130906

     }else if(name=='usCPImonthly'){
          .usCPImonthly<<-.usCPImonthly

     }else if(name=='usCPIannual'){
          .usCPIannual<<-.usCPIannual


     }else if(name=='moody_credit_yield'){
         # credit<<-credit
           #print("haha")
            .moody_AAA_yield_daily   <<-.moody_AAA_yield_daily 
            .moody_AAA_yield_monthly <<-.moody_AAA_yield_monthly 
            .moody_AAA_yield_annual  <<-.moody_AAA_yield_annual 
            .moody_Baa_yield_daily   <<-.moody_Baa_yield_daily 
            .moody_Baa_yield_monthly <<-.moody_Baa_yield_monthly 
            .moody_Baa_yield_annual  <<-.moody_Baa_yield_annual


      }else if(name=='credit'){
          .credit<<-.credit

     }else if(name=='AaaYieldMonthly'){
          .AaaYieldMonthly<<-.AaaYieldMonthly


      }else if(name=='AaaYieldDaily'){
          .AaaYieldDaily<<-.AaaYieldDaily

      }else if(name=='BaaMonthly'){
          .BaaMonthly<<-.BaaMonthly


      }else if(name=='BaaDaily'){
          .BaaDaily<<-.BaaDaily
 
      }else if(name=='usGDPannual'){
          .usGDPannual   <<-.usGDPannual

      }else if(name=='usGDPquarterly'){

          .usGDPquarterly<<-.usGDPquarterly


     }else if(name=='usDebt'){
          .usDebt<<-.usDebt

     }else if(name=='usUnemploymentRate'){
          .usUnemploymentRate<<-.usUnemploymentRate

     }else if(name=='sp500'){
          .sp500<<-.sp500

     }else if(name=='zipdata'){
          .zipdata<<-.zipdata

     }else if(name=='goldDailyPrice'){
          .goldDailyPrice<<-.goldDailyPrice

     }else if(name=='goldPriceAnnual'){
          .goldPriceAnnual<<-.x


     }else if(name=='goldPrice'){
          .goldPrice<<-.x


     }else if(name=='EDM1'){
          .EDM1<<-.EDM1
    }
}






