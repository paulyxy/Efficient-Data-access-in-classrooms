.officeHours<-function(){
"Topic: DANL100, FNCE311 and FNCE316 
Time: Jan 26, 2022 10:00 AM Eastern Time (US and Canada)
        Every week on Mon, Wed, Fri, until May 18, 2022, 49 occurrence(s)
        Jan 26, 2022 10:00 AM,       Jan 28, 2022 10:00 AM,       Jan 31, 2022 10:00 AM
        Feb 2, 2022 10:00 AM,        Feb 4, 2022 10:00 AM,        Feb 7, 2022 10:00 AM
        Feb 9, 2022 10:00 AM,        Feb 11, 2022 10:00 AM,       Feb 14, 2022 10:00 AM
        Feb 16, 2022 10:00 AM,       Feb 18, 2022 10:00 AM,       Feb 21, 2022 10:00 AM
        Feb 23, 2022 10:00 AM,       Feb 25, 2022 10:00 AM,       Feb 28, 2022 10:00 AM
        Mar 2, 2022 10:00 AM,        Mar 4, 2022 10:00 AM,        Mar 7, 2022 10:00 AM
        Mar 9, 2022 10:00 AM,        Mar 11, 2022 10:00 AM,       Mar 14, 2022 10:00 AM
        Mar 16, 2022 10:00 AM,       Mar 18, 2022 10:00 AM,       Mar 21, 2022 10:00 AM
        Mar 23, 2022 10:00 AM,       Mar 25, 2022 10:00 AM,       Mar 28, 2022 10:00 AM
        Mar 30, 2022 10:00 AM,       Apr 1, 2022 10:00 AM,        Apr 4, 2022 10:00 AM
        Apr 6, 2022 10:00 AM,        Apr 8, 2022 10:00 AM,        Apr 11, 2022 10:00 AM
        Apr 13, 2022 10:00 AM,       Apr 15, 2022 10:00 AM,       Apr 18, 2022 10:00 AM
        Apr 20, 2022 10:00 AM,       Apr 22, 2022 10:00 AM,       Apr 25, 2022 10:00 AM
        Apr 27, 2022 10:00 AM,       Apr 29, 2022 10:00 AM,       May 2, 2022 10:00 AM
        May 4, 2022 10:00 AM,        May 6, 2022 10:00 AM,        May 9, 2022 10:00 AM
        May 11, 2022 10:00 AM,       May 13, 2022 10:00 AM,       May 16, 2022 10:00 AM
        May 18, 2022 10:00 AM

Join Zoom Meeting
https://geneseo.zoom.us/j/82259544407?pwd=eWNnQWl5ZUpqWVd5dzlGNTJWcHo2dz09

Meeting ID: 822 5954 4407
Passcode: aaa

     Alternatively, http://datayyy.com/doc_txt/officeHours2022sring.txt 

";.officeHours_()}

.oh<-.officeHours

.officeHours_<-function(){
cat("

Topic: DANL100, FNCE311 and FNCE316 
Time: Jan 26, 2022 10:00 AM Eastern Time (US and Canada)
        Every week on Mon, Wed, Fri, until May 18, 2022, 49 occurrence(s)
        Jan 26, 2022 10:00 AM,        Jan 28, 2022 10:00 AM,        Jan 31, 2022 10:00 AM
        Feb 2, 2022 10:00 AM,        Feb 4, 2022 10:00 AM,        Feb 7, 2022 10:00 AM
        Feb 9, 2022 10:00 AM,        Feb 11, 2022 10:00 AM,        Feb 14, 2022 10:00 AM
        Feb 16, 2022 10:00 AM,        Feb 18, 2022 10:00 AM,        Feb 21, 2022 10:00 AM
        Feb 23, 2022 10:00 AM,        Feb 25, 2022 10:00 AM,        Feb 28, 2022 10:00 AM
        Mar 2, 2022 10:00 AM,        Mar 4, 2022 10:00 AM,        Mar 7, 2022 10:00 AM
        Mar 9, 2022 10:00 AM,        Mar 11, 2022 10:00 AM,        Mar 14, 2022 10:00 AM
        Mar 16, 2022 10:00 AM,        Mar 18, 2022 10:00 AM,        Mar 21, 2022 10:00 AM
        Mar 23, 2022 10:00 AM,        Mar 25, 2022 10:00 AM,        Mar 28, 2022 10:00 AM
        Mar 30, 2022 10:00 AM,        Apr 1, 2022 10:00 AM,        Apr 4, 2022 10:00 AM
        Apr 6, 2022 10:00 AM,        Apr 8, 2022 10:00 AM,        Apr 11, 2022 10:00 AM
        Apr 13, 2022 10:00 AM,        Apr 15, 2022 10:00 AM,        Apr 18, 2022 10:00 AM
        Apr 20, 2022 10:00 AM,        Apr 22, 2022 10:00 AM,        Apr 25, 2022 10:00 AM
        Apr 27, 2022 10:00 AM,        Apr 29, 2022 10:00 AM,        May 2, 2022 10:00 AM
        May 4, 2022 10:00 AM,        May 6, 2022 10:00 AM,        May 9, 2022 10:00 AM
        May 11, 2022 10:00 AM,        May 13, 2022 10:00 AM,        May 16, 2022 10:00 AM
        May 18, 2022 10:00 AM

Join Zoom Meeting
https://geneseo.zoom.us/j/82259544407?pwd=eWNnQWl5ZUpqWVd5dzlGNTJWcHo2dz09

Meeting ID: 822 5954 4407
Passcode: aaa

     Alternatively, http://datayyy.com/doc_txt/officeHours2022sring.txt 
")}













