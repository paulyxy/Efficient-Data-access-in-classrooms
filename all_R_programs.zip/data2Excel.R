.data2excel<-function(keyword_or_ID){
"Objective      : keyword or ID
   keyword_or_ID: such as 'c1_', 'c5_', 12, 44
                  Note: assume that the 'clipr' package is installed. 
                  install.packages('clipr')
          
 Example 1>.data2excel('c1_') # all images for chapter 1
              ID            NAME
            1  6 c1_place_holder
            2 28 data_c1_c16    
 
 Example 2>.d1('c1_')   # the same as the above 

 Example 3>.d1('c3_')   # for chapter 3
 
 Example 4>.d1('gdp)    # search by a keyword
              ID            NAME
            1 17 c4_GDPquarterly

 Example 5>.d1(17)      # get the data to Excel 
         For both Windows and Mac users:
             Launch Excel and paste! 

";.zdata2excel_(keyword_or_ID)}

.data2Excel<<-.data2excel
.d1<<-.data2excel


.zdata2excel_<-function(name){
     .path3<-"http://datayyy.com/if/data/"
     if(exists('.ifData')==FALSE){
          .tempPath<-paste0(.path3,"ifData",".RData")
          .ifData<<-get(load(url(.tempPath)))
     }

     if(typeof(name)=="character"){
          name<-toupper(name)
          out<-.ifData[grep(name,toupper(.ifData$NAME)),]
          rownames(out)<-NULL
          print(.leftAdj(out))
          
    }else{
         name2<-.ifData$NAME[name]
         infile<-paste0(.path3,name2,".csv")
         .x<-read.csv(infile)
         .write_clip(.x)
         cat("  For both Windows and Mac users:\n")
         cat("      Launch Excel and paste! \n")
    }
}
