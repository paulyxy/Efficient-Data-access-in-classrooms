.searchDrive<-function(nOrName=2,showID=0){
"Objective: find the numbers for data set given a chapter
      nOrName: integer or a name 
                 A list of all data sets (add later)

 Example #1:> .searchDrive()

 Example #2:> .searchDrive(-3)
 
 Example #3:> .searchDrive('bank')
     
";.searchDrive_(nOrName,showID)}

.dr1<-.searchDrive

.searchDrive_<-function(nOrName,showID){

  .path3<-"http://datayyy.com/"
  if(exists('.googleData')==FALSE){
        .tempPath<-paste0(.path3,"data_R/driveData.RData")
        load(url(.tempPath))
       .googleData<<-.x
  }


   if(typeof(nOrName)=="double"){

       # .show_n_obs(.googleData,nOrName)
       a<- .show_n_obs(.googleData,nOrName)

       if(showID==0){
            b<-data.frame(a$DATA_ID,a$NAME)
            colnames(b)<-c("DATA_ID","NAME")
            rownames(b)<-NULL
            return(b)
       }else{
           return(a)
      }
   }else{

       .a<-toupper(nOrName)
       .b<-toupper(.googleData$NAME)
       .z<-.googleData[grep(.a,.b),]

       if(showID==0){
          .y<-data.frame(.z$DATA_ID,.z$NAME)
          colnames(.y)<-c("DATA_ID","NAME")
          rownames(.y)<-NULL
         .y2<-format(.y, justify = "left")
          return(.y2)
       }else{
           .z2<-format(.z, justify = "left")
           rownames(.z2)<-NULL
          return(.z2)
      }

  }
}








