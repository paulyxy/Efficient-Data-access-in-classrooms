.show_jpg<-function(infile){
"Objective: show a jpg image

 Example 1: infile<-system.file('img', 'Rlogo.jpg', package='jpeg')
            .show_jpg(infile)

 Example 2:> infile<-'http://datayyy.com/images/milkyWay.jpg'
             .show_jpg(infile)

 Example 3: infile<-'http://datayyy.com/images/leaf.jpg'
             .show_jpg(infile)

";.zshow_jpg(infile)}

.zshow_jpg<-function(infile){

   a<-grep("http",infile)
   if(length(a)>0){
         outfile<-tempfile()
         download.file(infile,outfile,mode='wb',quiet=T)
         infile<-outfile
   }

   library(jpeg)
   img<-readJPEG(infile)
   # #
   if (exists("rasterImage")) { 
          plot(1:2, type='n')
          rasterImage(img, 1.01, 1.1, 1.95, 1.99)
    }else{
         cat('  function rasterImage() is missing \n')
    }
}

#rasterImage(image, xleft, ybottom, xright, ytop, angle = 0, interpolate = TRUE, ...)

