.pagesFile<-function(){
"How to Open Pages File
   The .pages file format is not supported by Windows system; it can't be opened directly 
      by double clicking. In fact, the pages file can be regarded as ZIP file since it 
      includes both the document information and a JPG file (or an optional PDF file) 
      used to preview the content. 

Method I: Copy & rename .pages file as a zip file
--------------------------------------
  t.pages --> t2.zip  --> double click it -->look for any PDF file and/or
     JPG images that has the same name with the .zip file (sometimes, it 
     may be also named as Preview).

Method II: open pages file in Google Docs
--------------------------------------
  Open Google and sign in with your account.
  Click on the Google apps icon (in the upper right corner).
  Select Docs from the drop-down list.
  Look for the Open file picker icon and click on it.
  Shift to the Upload option at the top.
  Drag a .pages file here -> drop it or click Select a file from your device 
     -> choose the pages file -> click   Open.

  Wait until you receive a message saying that There was a problem previewing this document.
    Click on the CloudConvert button (just below the error message).
    Choose Connect more apps and type CloudConvert to search for it.
    Select the file type you want to convert (.pages).
    Check the Save file to my Google Drive option.
    Click on the Start Conversion button and wait for the process to complete.
    Click on the Show File button to preview content of your pages file.

   https://www.minitool.com/news/open-pages-file-windows-pc.html
 
";.pagesFile()}

.pages<-.pagesFile

.pagesFile_<-function(){
cat("How to Open Pages File
   The .pages file format is not supported by Windows system; it can't be opened directly 
      by double clicking. In fact, the pages file can be regarded as ZIP file since it 
      includes both the document information and a JPG file (or an optional PDF file) 
      used to preview the content. 

Method I: Copy & rename .pages file as a zip file
--------------------------------------
  t.pages --> t2.zip  --> double click it -->look for any PDF file and/or
     JPG images that has the same name with the .zip file (sometimes, it 
     may be also named as Preview).

Method II: open pages file in Google Docs
--------------------------------------
  Open Google and sign in with your account.
  Click on the Google apps icon (in the upper right corner).
  Select Docs from the drop-down list.
  Look for the Open file picker icon and click on it.
  Shift to the Upload option at the top.
  Drag a .pages file here -> drop it or click Select a file from your device
     -> choose the pages file -> click   Open.

  Wait until you receive a message saying that There was a problem previewing this document.
    Click on the CloudConvert button (just below the error message).
    Choose Connect more apps and type CloudConvert to search for it.
    Select the file type you want to convert (.pages).
    Check the Save file to my Google Drive option.
    Click on the Start Conversion button and wait for the process to complete.
    Click on the Show File button to preview content of your pages file.

   https://www.minitool.com/news/open-pages-file-windows-pc.html
")}