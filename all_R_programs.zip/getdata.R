.getdata<-function(){
"
 *-----------------------------------------------------------------------*
 * .getdata                                                              *
 *-----------------------------------------------------------------------*
 *  Economics               -------------  Finance   -----------------   *
 *-----------------------------------------------------------------------*
 *  .show_usGDPannual       .show_ibmMonthly                             *
 *  show_usGDPquarterly     .show_ibmDaily                               *
 *-----------------------------------------------------------------------*
 * >.show_usGDPannual       # find its usage                             *
 * >.getdata                # back to this menu                          *
 * >.rpy                    # back to the main menu                      *
 *-----------------------------------------------------------------------*

";.getdata_()
}

.getdata_<-function(){
cat("
 *-----------------------------------------------------------------------*
 * .getdata                                                              *
 *-----------------------------------------------------------------------*
 *  Economics               -------------  Finance   -----------------   *
 *-----------------------------------------------------------------------*
 *  .show_usGDPannual       .show_ibmMonthly                             *
 *  show_usGDPquarterly     .show_ibmDaily                               *
 *-----------------------------------------------------------------------*
 * >.show_usGDPannual       # find its usage                             *
 * >.getdata                # back to this menu                          *
 * >.rpy                    # back to the main menu                      *
 *-----------------------------------------------------------------------*

")}

.gd<-.getdata


"

 *-----------------------------------------------------------------------*
 * .getdata                                                              *
 *-----------------------------------------------------------------------*
 *  Economics               -------------  Finance   -----------------   *
 *-----------------------------------------------------------------------*
 *                          .show_ibmMonthly
 *                          .show_ibmDaily 
 * .show_usGDPannual        .showff3Monthly           .show_ct1day       *
 * .show_usGDPquarterly     .showff3Daily             .show_cq1day       *
 * .show_usUnemployRate     .showffc4Monthly          .show_ct3month     *
 * .show_usDebt_annual      .showffc4Daily            .show_cq3month     *
 * .show_usCPI_annual       .showff5Monthly           .show_sp500monthly *
 * .show_usCPI_monthly      .showff5Daily             .show_sp500daily   *
 * .show_euroDollar_1m      .showAaaYieldDaily                           *
 * .show_dollarIndexMonthly .showBaaYieldMonthly      .getYahooDaily     *
 * .show_goldPrice          .showBaaYieldDaily                           *
 * .show_fedFundRate        .showTradingDaysDaily                        *
 * .show_vix                .showTradingDaysMonthly                      *
 *-----------------------------------------------------------------------*
 * >.show_usGDPannual       # find its usage                             *
 * >.getdata                # back to this menu                          *
 * >.fm                     # back to the main menu                      *
 *-----------------------------------------------------------------------*

"