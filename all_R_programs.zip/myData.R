
.myData<-function(infile=-9){
"Objective: instructor could give students his/her data set
            then students could use this function to get 
            the data set to Excel quickly. 

 infile  : location of infile
 

  Example #1: a='http://datayyy.com/data_csv/ibmMonthly.csv'
              .myData(a)

";.zmyData(infile)}


.zmyData<-function(infile){

   if(.is404(infile)==200){
      .x<-read.csv(infile)
      .showNobs(.x,0)
   }

}
    

