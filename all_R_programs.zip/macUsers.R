.macUsers<-function(i){
"Objective: help Mac users

  i    Explanation
 ---   -------------
  1    How to install R
  2    Use TextEdit On Mac 
  3    Change your working directory (Mac) 
  4    video: change your working directory (Mac) 
  5    TextEdit
  6    clipboard read:  [more detailed explanation] 
  7                     .readClipboardMac  : read from a clipborad for Mac users
  8    clipboard write: [more detailed explanation]
  9                    .writeClipboardMac : write to  a clipborad for Mac users 
 10                    .writeClipWindowsMac    for both Windows and Mac
 11                    .readClipWindowsMac     for both Windoes and Mac
 12    clear your R consol
 13    Virtual Lab
 14    Chroombook, PC and Mac
 15    New security app install for macOS users
 16    Using Python on a Mac
 17    Install pip on a Mac
 18    How To Correctly Install Python Modules On Mac!
 19    Save as as test.R or test.txt

";.macUsers_(i)}

.mac<-.macUsers
.nMac<-19

.macUsers_<-function(i){
   if(i<=.nMac){
      x<-paste0('cat(.MAC', i,')')
      .runText(x)
   }else{
      cat("Invalid number: input value should between 1 and ",.nMac, "\n")
   }
}

.MAC1<-"How to install R on a Mac machine
/////////////////////////////////////////////////

 1) Agrawal,Abhinav, 2014, Programming in R - Getting Started - Installing R and RStudio on a Mac (5m59s)
     (v42k,s4k,t5:59)
       https://www.youtube.com/watch?v=Ywj6yNfc5nM

 2) Data Science with Tom, 2020, How to install R & RStudio on Mac in 2021 - step-by-step walkthrough
    (s1k,v5k,t4:40)
    https://www.youtube.com/watch?v=LanBozXJjOk

 3) Merchant,Emily, 2019, Installing R and RStudio on a Mac (Jan. 2019)
    (v36k,s58,t3:01)
    https://www.youtube.com/watch?v=EmZqlcKkJMM&t=1s

//////////////////////////////////////////////////
"

.MAC2<-"Use TextEdit On Mac To Edit HTML Files
/////////////////////////////////////////////////
 Steps:     
 -------
      1) Search 'text'
      2) desktop -> new document
      3) enter  your code
      4) click 'file' -> 'save' 
          Save as
          Tag
          where 
          plain text encoding: Unicode (UTF-8)

     https://www.youtube.com/watch?v=zCN75v4Bbdk

//////////////////////////////////////////////////
"


.MAC3<-"change working director 
/////////////////////////////////////////////////
For Windows users, we can use 
-----------------------------
    setwd('c://temp')    # assume that c://temp exists
    getwd()

    # if c://temp does not exist

    dir.create(\"c://temp\")
    setwd('c://temp')  
    getwd()

For Mac and Windoes users: 
-------------------------------------------
 Step 1: get the current working directory 
      getwd()
      assume that it is /Users/pyan

 Step 2: # create a directory called 'temp'
      dir.create('temp')   
      setwd('temp')  
      getwd()

//////////////////////////////////////////////////
"

.MAC4<-"Video: change your working directory (Mac) 
/////////////////////////////////////////////////

 Agrawal,Abhinav,2014, R Programming tutorial - How to set working directory in R (Mac) - Programming in R
     (v38k,s4k,t4:33)
     https://www.youtube.com/watch?v=R30fX__WopM

//////////////////////////////////////////////////
"

# x<-�this is great�

.MAC5<-"TextEdit for Mac users 
/////////////////////////////////////////////////
For windows users
-----------------
       a) R editor
       b) RStudio editor
       c) NotePad

For Mac users
-----------------
       a) R editor
       b) RStudio editor
       c) TextEdit

  TextEdit
      download: https://macdownload.informer.com/textedit/
      Q&A       https://macdownload.informer.com/textedit/questions/
      help    : https://support.apple.com/guide/textedit/welcome/mac

//////////////////////////////////////////////////
"

.MAC6<-"Read from a clipborad for Mac users 
/////////////////////////////////////////////////

  data <- read.table(pipe(\"pbpaste\"))

  data <- read.table(pipe(\"pbpaste\"), header=T)

  data <- read.table(pipe(\"pbpaste\"), sep=\"\\t\", header=T)

    Note: 
        1) pipe('pbpaste') is the proper way to address the clipboard in Mac OS X, 
           while in Windows that would be 'clipboard'.

        2) '\\t' is for a tab

        3)  Ghislanzoni, Marco, 2013, Import data into R from Mac OS X clipboard
            http://marcoghislanzoni.com/blog/2013/10/27/import-data-r-mac-os-x-clipboard/

        4) a related image: http://datayyy.com/images/clipboardMac.png

        library(png)
        mac<-'http://datayyy.com/images/clipboardMac.png'
       .showPNG(mac)

//////////////////////////////////////////////////
"

.MAC7<-".readClipboardMac    function 
/////////////////////////////////////////////////
 I wrote a function to read data from clipboard for mac users. 

  Just type the function name to see its usage

  > .readClipboardMac

//////////////////////////////////////////////////
"

.MAC8<-"clipboard: write to a clipborad 
/////////////////////////////////////////////////
Method I:
---------
    data <- rbind(c(1,1,2,3), c(1,1, 3, 4), c(1,4,6,7))
    clip <- pipe(\"pbcopy\", \"w\")                       
    write.table(data, file=clip)                               
    close(clip)

Method II:
----------
   library(clipr)
   clipr::write_clip() # works on Windows, OS X, and X1

https://stackoverflow.com/questions/14547069/how-to-write-from-r-to-the-clipboard-on-a-mac/44727345

//////////////////////////////////////////////////
"

.MAC9<-".writeClipboardMac    function 
/////////////////////////////////////////////////
 I wrote a function to write data to a clipboard for mac users. 

  Just type the function name to see its usage

  > .writeClipboardMac

//////////////////////////////////////////////////
"


.MAC10<-"clipboard: .writeClipWindowsMac    for both types
/////////////////////////////////////////////////

   Justy type the function name to see its usage

     .writeClipWindowsMac

//////////////////////////////////////////////////
"

.MAC11<-".readClipWindowsMac     for both Windoes and Mac
/////////////////////////////////////////////////

  Just type its name to see the usage

    .readClipWindowsMac

//////////////////////////////////////////////////
"

.MAC12<-"Clear R console 
/////////////////////////////////////////////////
For Mac users: 4 methods
------------------------
    a) source('http://datayyy.com/rpy.txt')
      .cls()

    b) # define your own function
       cls<-function()cat(rep(\"\\n\",50))
       cls()

    c) cat(\"\\014\")   # ??

    d) cat(\"\\f\")     # ??

For windows users: 
-----------------
   a) Ctrl-l         # combination of the Ctrl-key and letter L key

   b) source('http://datayyy.com/rpy.txt')
      .cls()

   c) # define your own function
      cls<-function()cat(rep(\"\\n\",50))
      cls()
//////////////////////////////////////////////////
"

.MAC13<-"Virtual Lab for Mac users 
/////////////////////////////////////////////////
 The Virtual Lab is a cloud-based Windows computer lab that provides users 
     remote access to hardware and software that they would otherwise have to 
     install themselves on their own systems, or visit a computer lab to use. 
 
 Type the following command to see more

   .virtualLab   # or 

   .vl           # short-cut for .virtualLab, where l is lowercase of letter L)

   .v1           # short-cut for .virtualLab, where 1 is number 1 

//////////////////////////////////////////////////
"

.MAC14<-"Laptop vs. Chromebook
/////////////////////////////////////////////////
 Laptop vs. Chromebook: What's the difference and which best fits your needs
    Some Chromebooks can go toe-to-toe with Mac and Windows laptops, but they
    may not be best for everyone. Here's how to choose what's right for you.

  Chromebooks are laptops and two-in-ones running on Google's Chrome operating 
     system. The hardware might look like any other laptop, but the minimalistic,
     web-browser-based Chrome OS is a different experience from the Windows 
     and MacOS laptops you're likely used to. Whether you're considering 
     switching to one from a Windows laptop or MacBook, your kid received 
     one from their school or you're simply Chrome OS curious, here's everything you need to know. 

 For more, see the following link
     https://www.cnet.com/tech/computing/laptop-vs-chromebook-whats-the-difference-and-which-best-fits-your-needs/

//////////////////////////////////////////////////
"

.MAC15<-"New security app install for macOS users
/////////////////////////////////////////////////
 CIT will install a new app, called Nudge, on campus-owned macOS 
     computers on Tuesday, October 26. Nudge reminds users to 
     install critical macOS security patches in a timely manner.

 It will become increasingly persistent as a CIT-defined deadline 
     to install an update approaches. Nudge is also configured to 
     not interrupt active classroom work in an effort to minimize 
     disruption. For more on what to expect with Nudge, please 
     review the following Self Help article. Thank you for your
     help in keeping our campus-managed macOS devices as secure as possible.

//////////////////////////////////////////////////
"

.MAC16<-"Using Python on a Mac
/////////////////////////////////////////////////
    https://docs.python.org/3/using/mac.html
//////////////////////////////////////////////////
"

.MAC17<-"Mac: use the command line
/////////////////////////////////////////////////

 Cruz, Samantha, 2019, Install pip using command line on a Mac
     (s97,v41k,t2:01)
     https://www.youtube.com/watch?v=BCUppC__Px8

//////////////////////////////////////////////////
"

.MAC18<-"How To Correctly Install Python Modules On Mac
/////////////////////////////////////////////////

 Aspect, 2021, How To Correctly Install Python Modules On Mac!
     (s7,v476,t1:20)
      https://www.youtube.com/watch?v=bUQml8Rn9eY

//////////////////////////////////////////////////
"



.MAC19<-"Save as as test.R or test.txt
/////////////////////////////////////////////////

 Step 1: launch R

 Step 2: Click 'File' -> 'New Document' 
                      -> [type something such as pv<-100 ]
                      -> click 'File'
                      -> 'Save'
                      -> enter t.R  or t.txt
     
      When choosing a .txt extension, you will see 
           the following messgae. 
                 
     [Your have used the extension 
      '.txt as the end of the name. 
      The standard extension is '.R'. 
      You can choose to use the 
      standrad extension intead.]
             [ use .txt ]
             [ use .R   ]
             [ cancel   ]

//////////////////////////////////////////////////
"



# https://stackoverflow.com/questions/10294284/remove-all-special-characters-from-a-string-in-r

