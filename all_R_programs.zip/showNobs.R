.showNobs<-function(dataset,n=2){

.zshowNobs(dataset,n)}


.zshowNobs<-function(data,n){
   if(n>0){
        .x=head(data,n)
        return(.x)
   }else if(n<0){
        .x=tail(data,abs(n))
        return(.x)
    }else{


     a<-.getOS()
      if(a=="windows"){
           write.table(data,file="clipboard-16384", sep="\t", row.names=FALSE)
           cat(" Windows users: launch Excel and paste\n\n")
      }else{
           clip <- pipe("pbcopy", "w")                       
           write.table(data,row.names=F,file=clip)         # row.names = TRUE                      
           close(clip)
           cat(" Mac users: launch Excel and paste\n\n")
      }
    }
}



