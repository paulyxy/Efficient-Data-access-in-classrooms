.is404<-function(remoteFile){
"Objective: Check the existence of a remote file
  remoteFile: a remote file
              output value:200   yes
                           404   no
              Note: this program uses an R 'httr' package.
                    You can install it by issing the following code. 
                    install.packages('httr')

 Example #1>.is404('http://datayyy.com/rpy.txt')
            [1] 200

 Example #2>.is404('http://datayyy.com/rpy.txt')  # .is404():short-cut
            [1] 200

 Example #3>.is404('http://datayyy.com/rpy.R')
             [1] 200

 Example #4>url<-'http://datayyy.com/data_excel/ff3Monthly.xxx'
           >.is404(url)  
             [1] 404

";.zis404_(remoteFile)}

.zis404_<-function(remoteFile){

    x<-typeof(remoteFile)
    if(x!="character"){
       error<-"Error message: input should be a string"
       return(error)
    }

   x<-"httr" %in% .packages(all.available=T)
   if(x==FALSE){
     error<-'Please install the "httr" R package:\ninstall.packages("httr")\n'
     return(error)
   }

   library(httr)
   status <- HEAD(remoteFile)
   a<-status$status_code
   return(a)
}

