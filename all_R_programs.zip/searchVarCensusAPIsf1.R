
.searchVarCensusAPIsf1<-function(var){
"Objective: get definition of a given variable name 
            for Census API SF1

 Example #1>.searchVarCensusAPIsf1('cd111')
             [1] 'name: CD111,'                           
             [2] 'label: Congressional District (111th) ,'
             [3] 'group: N/A,'
             [4] 'limit: 0'      

 Example #2>.searchVarCensusAPIsf1('AIANHH')
            [1] 'name: AIANHH,'
            [2] 'label: American Indian Area/Alaska Native Area/Hawaiian Home Land,'
            [3] 'group: N/A,'
            [4] 'limit: 0'

 Example #3>.searchVarCensusAPIsf1('aaa')
            Error message: no such variable called  'aaa' 

";.searchVarCensusAPIsf1_(var)}

.searchVarCensusAPIsf1_<-function(var){
   path<-"https://api.census.gov/data/2010/dec/sf1/variables/"
   #var<-'cd111'
   #var<-'AIANHH'
   infile<-paste0(path,toupper(var),".json")

  tryCatch({
     x<-readLines(infile)
     a<-x[grep(":",x)]
     b<-gsub("\"","",a)
     d<-gsub("^ *","",b)
     return(d)
  }, error = function(e){
     var2<-paste0("'",var,"'")
     cat("  Error message: no such variable called ",var2,"\n")
 }
 )

}








