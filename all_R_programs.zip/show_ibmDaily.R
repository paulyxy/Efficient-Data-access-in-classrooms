.show_ibmDaily<-function(n=2,format=1){
" Objective: show the IBM daily data 
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations
   format  : 1 (default value) for Excel  .show_ibmMonthly(0)
             2 or other value  for R      .show_ibmMonthly(0,2)

 Example 1: >.show_ibmDaily()
                DATE     OPEN     HIGH      LOW    CLOSE ADJ.CLOSE VOLUME
        1 1962-01-02 7.713333 7.713333 7.626667 7.626667  0.689273 387200
        2 1962-01-03 7.626667 7.693333 7.626667 7.693333  0.695299 288000

 Example 2: >.show_ibmDaily(1)
                DATE     OPEN     HIGH      LOW    CLOSE ADJ.CLOSE VOLUME
        1 1962-01-02 7.713333 7.713333 7.626667 7.626667  0.689273 387200

 Example 3: > .show_ibmDaily(-2)
               DATE   OPEN   HIGH    LOW  CLOSE ADJ.CLOSE  VOLUME
    14140 2018-03-05 154.12 157.49 153.75 156.95    156.95 3670600
    14141 2018-03-06 157.28 157.89 155.16 155.72    155.72 3586600

 Example 4:.show_ibmDaily(0)        # get all to Excel
            Launch Excel and paste

 Example 5:.show_ibmDaily(0,2)      # copy all to .x 
            Note that the data set is .x

";.show_ibmDaily_(n,format)}

.show_ibmDaily_<-function(n,format){
   if(exists('.ibmDaily')==FALSE){
        #.load_yan("ibmDaily")        
        load(url("http://datayyy.com/data_R/ibmDaily.RData"))
        .ibmDaily<<-.x
   }

   if(n==0 & format!=1){
        .x<<-.ibmDaily 
        cat(" Note that the data set is .x\n")
   }else{
        .show_n_obs(.ibmDaily,n)
   }


}

