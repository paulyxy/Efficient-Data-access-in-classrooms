
# ----------------------------------------------------- #
# --- US Un-employment rate (annual) ------------------ #
# ----------------------------------------------------- #
# ----------------------------------------------------- #
# ----------------------------------------------------- #
.show_usUnemployRate<-function(n=2){
"Objective: show the US unemployment 
   n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs

      source: https://research.stlouisfed.org/fred2/series/UNRATE/downloaddata
      range : 1948 -2016

 Example 1:> > .show_usUnemployRate()
                   DATE UNEMPLOYMENTRATE
           1 1948-01-01             0.07
           2 1949-01-01             0.27

 Example 2:> .show_usUnemployRate(-5)
                 DATE UNEMPLOYMENTRATE
        65 2012-01-01             0.39
        66 2013-01-01             0.35
        67 2014-01-01             0.28
        68 2015-01-01             0.20
        69 2016-01-01             0.01

";.show_usUnemployRate_(n)
}
.show_usUnemployRate_<-function(n){
   if(exists('.usUnemploymentRate')==FALSE).load_yan("usUnemploymentRate")
  
    .show_n_obs(.usUnemploymentRate,n)

}

