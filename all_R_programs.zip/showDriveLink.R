.showDriveLink<-function(data_ID){
"Objective: manually download a file from my Google Drive 
   data_ID : an integer 

 Example #1:> .showDriveLink(2)
              The link for  ibmMonthly.csv :
                https://drive.google.com/uc?id=1HEm2rDEuoRgkum7QlUSUkWStuFds5vyJ&export=download 

 Example #2:> .dr4(3)
      
";.showDriveLink_(data_ID)}

.dr4<-.showDriveLink

# https://drive.google.com/uc?id=1HEm2rDEuoRgkum7QlUSUkWStuFds5vyJ&export=download

# a<-read.csv("https://drive.google.com/uc?id=1HEm2rDEuoRgkum7QlUSUkWStuFds5vyJ&export=download")

.showDriveLink_<-function(i){
   .path3<-"http://datayyy.com/"
   if(exists('.googleData')==FALSE){
       .tempPath<-paste0(.path3,"data_R/driveData.RData")
       load(url(.tempPath))
       .googleData<<-.x
    }

   n<-nrow(.googleData)
   if(i>=1 & i<=n){
       name<-.googleData$NAME[i]

       a<-"https://drive.google.com/uc?id="
       b<-"&export=download"
       d<-.googleData$ID[i]
       link<-paste0(a,d,b)

       cat(" The link for ",name, ":\n")
       cat(" ",link, "\n")
  }else{
      cat(" data_ID should be between 1 and ",n,"\n")
  }

}









