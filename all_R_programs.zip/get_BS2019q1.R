.get_BS2019q1<-function(ticker){
"Objective: show Fama-French 3 monthly factors
        n  : n > 0 for the first n obs (default is 2)
             n < 0 for the last  n obs
             n = 0 for all observations

 Example 1:> .show_BS2019q1('ibm')  
              Window users: launch Excel and paste

 Example 2:> .show_BS2019q1(0) # get all tickers
              Window users: launch Excel and paste
       
";.zget_BS2019q1(ticker)}

.zget_BS2019q1<-function(ticker){
   if(exists('.bs2019q1D')==FALSE){
      .bs2019q1D<<-get(load(url("http://datayyy.com/data_R/bs2019q1.RData")))
   }
    

   # print(head(out))
   if(ticker==0){
        out<-data.frame(unique(.bs2019q1D$TICKER))
        colnames(out)<-'TICKER'
        out<-out[order(out$TICKER),]
        cat(' Generate unique tickers \n')
   }else{
       ticker<-toupper(ticker)
       out<- .bs2019q1D[grep(ticker,.bs2019q1D$TICKER),]
   }
   .showNobs(out,0)
}




