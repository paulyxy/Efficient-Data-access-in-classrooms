.get_CF5<-function(ticker="ibm"){
"Objective: Get the Income Statement: IBM, WMT, AAPL, JNJ, or GM

 Example 1:> .get_CF5('ibm')  
              Window users: launch Excel and paste
      
";.zget_CF5(ticker)}

.zget_CF5<-function(ticker){
   if(exists('.CF5D')==FALSE){
      .CF5D<<-get(load(url("http://datayyy.com/getdata/cf5.RData")))
   }
    
   ticker<-toupper(ticker)

   tickers<-unique(.CF5D$TICKER)

   a<-grep(ticker,tickers)
   if(length(a)==0){
      cat(' Ticker should be one of \n')
      print(tickers)
   }else{
       out<- .CF5D[grep(ticker,.CF5D$TICKER),]
       rownames(out)<-NULL
       .showNobs(out,0)
   }
}




