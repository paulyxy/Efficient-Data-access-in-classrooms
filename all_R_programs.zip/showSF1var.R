.showSF1var<-function(data_ID){
"Objective: manually download a file from my Google Drive 
   data_ID : an integer 

 Example #1:> .showSF1var(2)

 Example #2:> .dr4(3)
      
";.showSF1var_(data_ID)}

.dr4<-.showSF1var


.showSF1var_<-function(i){
   .path3<-"http://datayyy.com/"
   if(exists('.sf1Vars')==FALSE){
       .tempPath<-paste0(.path3,"data_R/sf1Vars.RData")
       .sf1Vars<-get(load(url(.tempPath)))
    }

   n<-nrow(.sf1Vars)

   if(i>=1 & i<=n){


  }else{
      cat(" data_ID should be between 1 and ",n,"\n")
  }

}









