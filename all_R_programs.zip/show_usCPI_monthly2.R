
.show_usCPI_monthly<-function(n=2){
"Objetive: show the CIP monthly data
    n   : number of observations (default is 2)
             n > 0 for the first n obs
             n < 0 for the last  n obs
             n = 0 for all obs

    source: http://data.bls.gov/timeseries/CUSR0000SA0?output_view=pct_1mth  
    range : 1947 -2016

 Example 1:> .show_usCPI_monthly()
              YEAR   JAN   FEB    MAR   APR    MAY   JUN   JUL   AUG    SEP    OCT    NOV    DEC
            1 1947    NA 0.007  0.018 0.000 -0.002 0.006 0.007 0.008  0.020  0.003  0.007  0.015
            2 1948 0.012 0.000 -0.007 0.014  0.008 0.006 0.010 0.001 -0.003 -0.002 -0.006 -0.005

 Example 2: > .show_usCPI_monthly(-4)
              YEAR    JAN    FEB    MAR    APR   MAY   JUN   JUL   AUG    SEP   OCT    NOV    DEC
           67 2013  0.002  0.006 -0.003 -0.002 0.000 0.002 0.002 0.002  0.002 0.001  0.002  0.003
           68 2014  0.003  0.001  0.001  0.003 0.001 0.001 0.001 0.000  0.001 0.001 -0.002 -0.003
           69 2015 -0.006  0.002  0.002  0.001 0.003 0.002 0.001 0.000 -0.001 0.002  0.001 -0.001
           70 2016  0.000 -0.002  0.001  0.004 0.002    NA    NA    NA     NA    NA     NA     NA

 Example 3:> x=.show_usCPI_monthly(0)
           > dim(x)
             [1] 70 13

";.show_usCPI_monthly_(n)
}


.show_usCPI_monthly_<-function(n){
   if(exists('.usCPImonthly')==FALSE) .load_yan("usCPImonthly")

   .show_n_obs(.usCPImonthly,n)
}

