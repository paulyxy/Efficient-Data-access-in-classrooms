.showWebs<-function(ID){
"Objective: show a website or using the browseURl() function. 
   wordOrN: keyword or a ID

";.showWebs_(ID)}

.showWebs_<-function(ID){
     .path3<-"http://datayyy.com/getdata/"
     if(exists('.getdataWebs')==FALSE){
           .tempPath<-paste0(.path3,"websites",".RData")
           x<-get(load(url(.tempPath)))
           x2<-data.frame(1:nrow(x),x)
           colnames(x2)<-c("ID","NAME","WEBSITE")
           .getdataWebs<<-x2
        }

    a<-.getdataWebs[ID,]$WEBSITE

    b<-grep("https?",a)
    if(length(b)>=1){
       browseURL(a)
    }else{
      cat("this is not a website\n")
    }
}


