.project<-function(i){
"A list of potential interesting projects. 
  [optional and could be used as extra credit]
 i Project examples                     i  Projects                            i  Names 
-- --------------------------          --- -------------------------           --  ---------------------
 1 Three types of projects             21 Issues with import cv2               41 Combine 2 videos    [3 lines]
 2 os.system() function                22 Type II: example #13: ASCII art      42 Images to a video   [4 lines]
 3 Type I: example: text to voice      23            [original code]           43 Add a text to video [5 lines]
 4                  [original code]    24 Speech to text (good)                44 GIF from jpg images [5 lines]
 5 Speech to text:(School of Business) 25 issues with import PyAudio[not Done] 45 Movie to one image
 6 Type I:example Scholarly module     26 sys.argv explanation                 46 Make a short video
 7 Type I:example:sentiment score      27 Type III: example 14:Google Scholar  47 Cool effect
 8                  [original code]    28            [more complete code]  10  48 Generate a sin video
 9 Type II:example: playsound          29 Screenshot every 4 seconds           49 Free vidoes,images,music,and sound
10 Type II:example: fetch http status  30             [II]                     50 retrieve text from image   
11 Type II:example: text to morse code 31             [original code] 
12 Type II:example: PDF to text        32 find dominant color for a given image 
13                 [original code]     33             [original code]
14 Type II:example add a water mark    34 password generator 
15                 [original code]     35             [original code]
16 Type II:example tic-tac-toe         36 moviepy:installation 
17 Type II:example Sine game           37        :generate a png    [2 lines]
18 Type ii:example check spelling      38        :cut your video    [2 lines]
19 Type II:example: JPEG to png image  39        :rotate 180 degree [2 lines]
20 Type II:example: digital clock      40        :GIF from a video  [2 lines]

  .pp  # short-cut 

";.project_(i)}

.pp<<-.project
.nProject<-50

.project_<-function(i){
   if(i<=.nProject){
      x<-paste0('cat(.projectP',i,')')
      .runText(x)
   }else{
       cat(" Input value should be between 1 and ",.nProject,"\n")
   }
}

.projectP1<-"Requirements of a project 
//////////////////////////////////////////////
Three types of projects: 
     Type   I: study one R package or Python module
     Type  II: study one 'project' found at the Github website
     Type III: A true project 

Objective: apply what you have learnt from this course 
           to a real-world situation. 

Format: Group project (each group could have up to three members) 

Topic:  Each group chooses one topic from a list of potential term 
        projects (first come and first served since each topic should 
        be chosen by just one group). 

Two files: Each group should submit the following two files 
         a) A text file contains your code
         b) a short report (maximum page limit: 15, double space, font of 11)

Dropbox : submit your files to the drop box on Canvas
Due date: three days after the final exam
//////////////////////////////////////////////
"
.projectP2<-"os.system() function 
////////////////////////////////////////////////
from download import download
infile=\"http://datayyy.com/images/banana.png\"
outfile=\"banana.png\"
download(infile,outfile)
#
import os
os.system(outfile) 
////////////////////////////////////////////////
"

.projectP3<-"Example #1: text to voice
////////////////////////////////////////////////

from gtts import gTTS
string =\"Prof. Yan is teaching Programming for Data Analytics\"
x = gTTS(text=string, lang='en', slow=False)
x.save(\"test.mp3\")

////////////////////////////////////////////////
"

.projectP4<-"Example #1: original code
////////////////////////////////////////////////
#Importing Libraries
#Importing Google Text to Speech library
from gtts import gTTS

#Importing PDF reader PyPDF2
import PyPDF2

#Open file Path
pdf_File = open('name.pdf', 'rb') 

#Create PDF Reader Object
pdf_Reader = PyPDF2.PdfFileReader(pdf_File)
count = pdf_Reader.numPages # counts number of pages in pdf
textList = []

#Extracting text data from each page of the pdf file
for i in range(count):
   try:
    page = pdf_Reader.getPage(i)    
    textList.append(page.extractText())
   except:
       pass

#Converting multiline text to single line text
textString = \" \".join(textList)

print(textString)

#Set language to english (en)
language = 'en'

#Call GTTS
myAudio = gTTS(text=textString, lang=language, slow=False)

#Save as mp3 file
myAudio.save(\"Audio.mp3\")

# source:https://github.com/Python-World/python-mini-projects
////////////////////////////////////////////////
"


.projectP5<-"Speech to text (Geneseo school of business) 
////////////////////////////////////////////////
import speech_recognition as sr

infile=\"sob1.wav\"
r = sr.Recognizer()
with sr.AudioFile(infile) as source:
    audio_data = r.record(source)
    text = r.recognize_google(audio_data)
    print(text)

////////////////////////////////////////////////
"

.projectP6<-"Python scholarly module 
////////////////////////////////////////////////
from scholarly import scholarly 

x = scholarly.search_author('Marty Banks, Berkeley')
scholarly.pprint(next(x))

x = scholarly.search_author('Paul Yan, Geneseo')
scholarly.pprint(next(x))

////////////////////////////////////////////////
"

.projectP7<-"Example #3: sentiment score of one sentence
////////////////////////////////////////////////
# pip install textblob

from textblob import TextBlob
text =\"this is a sad story\"  # -0.5
x = TextBlob(str(text))
print(x.sentiment.polarity)

////////////////////////////////////////////////
"

.projectP8<-"setiment [original code] 
////////////////////////////////////////////////
from textblob import TextBlob
text='''
The titular threat of The Blob has always struck me as the ultimate movie
monster: an insatiably hungry, amoeba-like mass able to penetrate
virtually any safeguard, capable of--as a doomed doctor chillingly
describes it--\"assimilating flesh on contact.
Snide comparisons to gelatin be damned, it's a concept with the most
devastating of potential consequences, not unlike the grey goo scenario
proposed by technological theorists fearful of
artificial intelligence run rampant.
'''

blob = TextBlob(str(text))
blob.tags # [('The', 'DT'), ('titular', 'JJ'),('threat','NN'),('of','IN'), ...]
blob.noun_phrases # WordList(['titular threat', 'blob',
                  # 'ultimate movie monster','amoeba-like mass', ...])
for sentence in blob.sentences:
    print(sentence.sentiment.polarity)

 # 0.06000000000000001
#-0.34166666666666673
////////////////////////////////////////////////
"

.projectP9<-"playsound Python module
////////////////////////////////////////////////
#pip install playsound==1.2.2

import os
import playsound
playsound.playsound('c://temp/test22.mp3', False)

////////////////////////////////////////////////
"

.projectP10<-"Example #4: fetch http status
////////////////////////////////////////////////
#Program to fetch the http status code give the url/api
from urllib.request import urlopen
from urllib.error import URLError, HTTPError
import emoji

#Taking input url from user
requestURL = input(\"Enter the URL to be invoked: \")

#Gets the response from URL and prints the status code, corresponding emoji and message accordingly
try:
    response = urlopen(requestURL)
    #In case of success, prints success status code and thumbs_up emoji
    print('Status code : ' + str(response.code) + ' ' + emoji.emojize(':thumbs_up:'))
    print('Message : ' + 'Request succeeded. Request returned message - ' + response.reason)
except HTTPError as e:
    #In case of request failure, prints HTTP error status code and thumbs_down emoji
    print('Status : ' + str(e.code) + ' ' + emoji.emojize(':thumbs_down:'))
    print('Message : Request failed. Request returned reason - ' + e.reason)
except URLError as e:
    #In case of bad URL or connection failure, prints Win Error and thumbs_down emoji
    print('Status :',  str(e.reason).split(']')[0].replace('[','') +  ' ' + emoji.emojize(':thumbs_down:'))
    print('Message : '+ str(e.reason).split(']')[1])

////////////////////////////////////////////////
"

.projectP11<-"text to morse code
////////////////////////////////////////////////
#all_the symbols
symbols = {
    \"a\": \".-\",     \"b\": \"-...\",     \"c\": \"-.-.\",
    \"d\": \"-..\",     \"e\": \".\",     \"f\": \"..-.\",
    \"g\": \".-\",      \"h\": \"....\",     \"i\": \"..\",
    \"j\": \".---\",     \"k\": \"-.-\",     \"l\": \".-..\",
    \"m\": \"--\",     \"n\": \"-.\",     \"o\": \"---\",
    \"p\": \".--.\",     \"q\": \"--.-\",     \"r\": \".-.\",
    \"s\": \"...\",     \"t\": \"-\",     \"u\": \"..-\",
    \"v\": \"...-\",     \"w\": \".--\",     \"x\": \"-..-\",
    \"y\": \"-.--\",     \"z\": \"--..\",
}

#the user has to type a word
ask = input(\"type: \")
length = len(ask)
output = \"\"

for i in range(length):
    if ask[i] in symbols.keys():
        output = output + \" \" + symbols.get(ask[i])

print(output)  
////////////////////////////////////////////////
"

.projectP12<-"PDF to text
////////////////////////////////////////////////
import os
import PyPDF2
#
infile=\"c://temp/test.pdf\"
outfile=\"c://temp/t.txt\"
#
pdfobj = open(infile, 'rb')
pdfread = PyPDF2.PdfFileReader(pdfobj)
x = pdfread.numPages
#
for i in range(x):
    pageObj = pdfread.getPage(i)
    with open(outfile, 'a+') as f: 
        f.write((pageObj.extractText()))
    print(pageObj.extractText()) # print your text
#    
pdfobj.close()  
////////////////////////////////////////////////
"

.projectP13<-"PDF to text (convert.py)
////////////////////////////////////////////////
import PyPDF2
import os

if(os.path.isdir(\"temp\") == False):
    os.mkdir(\"temp\")
    
txtpath = \"\"
pdfpath = \"\"

pdfpath = input(\"Enter the name of your pdf file - please use backslash when typing in directory path: \")   #Provide the path for your pdf here
txtpath = input(\"Enter the name of your txt file - please use backslash when typing in directory path: \")   #Provide the path for the output text file  

BASEDIR = os.path.realpath(\"temp\") # This is the sample base directory where all your text files will be stored if you do not give a specific path
print(BASEDIR)


if(len(txtpath) == 0):
    txtpath = os.path.join(BASEDIR,os.path.basename(os.path.normpath(pdfpath)).replace(\".pdf\", \"\")+\".txt\")
pdfobj = open(pdfpath, 'rb')

pdfread = PyPDF2.PdfFileReader(pdfobj)
x = pdfread.numPages
for i in range(x):
    pageObj = pdfread.getPage(i)
    with open(txtpath, 'a+') as f: 
        f.write((pageObj.extractText()))
    print(pageObj.extractText()) #This just provides the overview of what is being added to your output, you can remove it if want
pdfobj.close()  
////////////////////////////////////////////////
"

.projectP14<-"add a water mark 
////////////////////////////////////////////////
import os
from PIL import Image
#
infile1=\"fun.png\"
infile2=\"danl100_2.png\"
outfile=\"fun2.png\"
#
base_image = Image.open(infile1) 
watermark = Image.open(infile2).convert(\"RGBA\")
position = base_image.size
newsize = (int(position[0]*8/100),int(position[0]*8/100))
watermark = watermark.resize(newsize)
new_position = position[0]-newsize[0]-20,position[1]-newsize[1]-20
    # create a new transparent image
transparent = Image.new(mode='RGBA',size=position,color=(0,0,0,0))
    # paste the original image
transparent.paste(base_image,(0,0))
    # paste the watermark image
transparent.paste(watermark,new_position,watermark)
image_mode = base_image.mode
transparent = transparent.convert('P')
transparent.save(outfile,optimize=True,quality=100)
print(\"Saving...\")

////////////////////////////////////////////////
"

.projectP15<-"add a water mark (original code)
////////////////////////////////////////////////
import os
from PIL import Image

def watermark_photo(input_image_path,watermark_image_path,output_image_path):
    base_image = Image.open(input_image_path)
    watermark = Image.open(watermark_image_path).convert(\"RGBA\")
    # add watermark to your image
    position = base_image.size
    newsize = (int(position[0]*8/100),int(position[0]*8/100))
    # print(position)
    watermark = watermark.resize(newsize)
    # print(newsize)
    # return watermark

    new_position = position[0]-newsize[0]-20,position[1]-newsize[1]-20
    # create a new transparent image
    transparent = Image.new(mode='RGBA',size=position,color=(0,0,0,0))
    # paste the original image
    transparent.paste(base_image,(0,0))
    # paste the watermark image
    transparent.paste(watermark,new_position,watermark)
    image_mode = base_image.mode
    print(image_mode)
    if image_mode == 'RGB':
        transparent = transparent.convert(image_mode)
    else:
        transparent = transparent.convert('P')
    transparent.save(output_image_path,optimize=True,quality=100)
    print(\"Saving\"+output_image_path+\"...\")

folder = input(\"Enter Folder Path:\")
watermark = input(\"Enter Watermark Path:\")
os.chdir(folder)
files = os.listdir(os.getcwd())
print(files)

if not os.path.isdir(\"output\"):
    os.mkdir(\"output\")

c = 1
for f in files:
    if os.path.isfile(os.path.abspath(f)):
        if f.endswith(\".png\") or f.endswith(\".jpg\"):
            watermark_photo(f,watermark,\"output/\"+f)
////////////////////////////////////////////////
"

.projectP16<-"tic-tac-toe
////////////////////////////////////////////////
squares = [' ']*9
players = 'XO'
board = '''
  0   1   2
  {0} | {1} | {2}
 -----------
3 {3} | {4} | {5} 5
 -----------
  {6} | {7} | {8}
  6   7   8
'''
win_conditions = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8), # horizontals
    (0, 3, 6), (1, 4, 7), (2, 5, 8), # verticals
    (0, 4, 8), (2, 4, 6)             # diagonals
]

def check_win(player):
    for a, b, c in win_conditions:
        if {squares[a], squares[b], squares[c]} == {player}:
            return True
#
while True:
    print(board.format(*squares))
    if check_win(players[1]):
        print(f'{players[1]} is the winner!')
        break
    if ' ' not in squares:
        print('Cats game!')
        break
    move = input(f'{players[0]} to move [0-8] > ')
    if not move.isdigit() or not 0 <= int(move) <= 8 or squares[int(move)] != ' ':
        print('Invalid move!')
        continue
    squares[int(move)], players = players[0], players[::-1]
////////////////////////////////////////////////
"

.projectP17<-"Sine game
////////////////////////////////////////////////
from math import *
from turtle import *
#
A = 50      # Amplitude
B = 100     # WaveLength
C = 0       # Horizontal Shift
D = 0       # Vertical Shift
#
penup()
# As x increases y increases and decreases as it is evaluated.
for x in range(-200, 200):
    # Sine Wave Equation
    y = A * sin((2 * pi / B) * (x + C)) + D
    goto(x, y)
    pendown()
#
hideturtle()
mainloop()

////////////////////////////////////////////////
"

.projectP18<-"check spelling
////////////////////////////////////////////////
from textblob import TextBlob  
t = 1
while t:
    a = input(\"Enter the word to be checked:- \")
    print(\"original text: \"+str(a))  #printing original text

    b = TextBlob(a)  #correcting the text
    # prints the corrected spelling
    print(\"corrected text: \"+str(b.correct()))
    t = int(input(\"Try Again? 1 : 0 \"))

////////////////////////////////////////////////
"

.projectP19<-"JPEG to png image 
////////////////////////////////////////////////
import tkinter as tk
from PIL import Image
from tkinter import filedialog
#
root = tk.Tk()   # Tkinter window initialized
root.title('Converter')     # Title of the window
canvas1 = tk.Canvas(root,width=300,height=250,bg='orange',relief='raised')
canvas1.pack()
label1 = tk.Label(root,text='File Converter',bg='lightsteelblue2') # title to the screen
label1.config(font=('helvetica', 20))
canvas1.create_window(150, 60, window=label1)
im1 = None  # variable to store path of image
#
def getJPG():
    '''Function to get image location and open it with pillow'''
    global im1
    import_file_path = filedialog.askopenfilename()
    im1 = Image.open(import_file_path)
#
font = ('helvetica',12,'bold')
bg = 'royalblue'
fg = 'white'
browseButton_JPG=tk.Button(text=\"  Import JPEG File     \",command=getJPG,bg=bg,fg=fg,font=font)   # Browse button
canvas1.create_window(150, 130, window=browseButton_JPG)
def convertToPNG():
    '''Function to change file extenstion to png and save it to User's prefered location '''
    global im1
    if im1 is None:
        tk.messagebox.showerror(\"Error\", \"No File selected\")
    else:
        export_file_path = filedialog.asksaveasfilename(defaultextension='.png')
        im1.save(export_file_path)
#
saveAsButton_PNG=tk.Button(text='Convert JPEG to PNG',command=convertToPNG,bg=bg,fg=fg,font=font)#Convert button
canvas1.create_window(150, 180, window=saveAsButton_PNG)
root.mainloop()
////////////////////////////////////////////////
"

.projectP20<-"digital clock
////////////////////////////////////////////////
import tkinter as tk
from time import strftime
#
def light_theme():
    frame = tk.Frame(root, bg=\"white\")
    frame.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.8)
    lbl_1 = tk.Label(frame, font=('calibri', 40, 'bold'),
                     background='White', foreground='black')
    lbl_1.pack(anchor=\"s\")
    def time():
        string = strftime('%I:%M:%S %p')
        lbl_1.config(text=string)
        lbl_1.after(1000, time)
    time()
def dark_theme():
    frame = tk.Frame(root, bg=\"#22478a\")
    frame.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.8)
    lbl_2 = tk.Label(frame, font=('calibri', 40, 'bold'),
                     background='#22478a', foreground='black')
    lbl_2.pack(anchor=\"s\")
    def time():
        string = strftime('%I:%M:%S %p')
        lbl_2.config(text=string)
        lbl_2.after(1000, time)
    time()
#
root = tk.Tk()
root.title(\"Digital-Clock\")
canvas = tk.Canvas(root, height=140, width=400)
canvas.pack()
frame = tk.Frame(root, bg='#22478a')
frame.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.8)
lbl = tk.Label(frame, font=('calibri', 40, 'bold'),
                     background='#22478a', foreground='black')
lbl.pack(anchor=\"s\")
def time():
    string = strftime('%I:%M:%S %p')
    lbl.config(text=string)
    lbl.after(1000, time)
time()
menubar = tk.Menu(root)
theme_menu = tk.Menu(menubar, tearoff=0)
theme_menu.add_command(label=\"Light\", command=light_theme)
theme_menu.add_command(label=\"Dark\", command=dark_theme)
menubar.add_cascade(label=\"Theme\", menu=theme_menu)
root.config(menu=menubar)
root.mainloop()
////////////////////////////////////////////////
"

.projectP21<-"Issue with the Python csv2 module 
////////////////////////////////////////////////
should install the following module instead   

pip install opencv-python

import cv2

////////////////////////////////////////////////
"

.projectP22<-"Make art [letter for art]
////////////////////////////////////////////////
from download import download
infile=\"http://datayyy.com/images/leaf.jpg\"
outfile=\"leaf.jpg\"
download(infile,outfile)
#
import cv2
importsys
import numpy as np
symbols_list = [\"#\", \"-\", \"*\", \".\", \"+\", \"o\"]
threshold_list = [0, 50, 100, 150, 200]
threshold_list = [0, 50, 100, 150, 200]
image_path =outfile
image = cv2.imread(image_path, 0)  # read image
height, width = image.shape        # adjust these parameters if not fit
new_width = int(width/10)          # original one 20
new_height = int(height/30)        # original one 40
resized_image = cv2.resize(image, (new_width, new_height),) # resize to fit
thresh_image = np.zeros(resized_image.shape)
for i, threshold in enumerate(threshold_list):
    thresh_image[resized_image > threshold] = i # assign according to index 
#
for row in thresh_image:
    for e in row:
        print(symbols_list[int(e) % len(symbols_list)], end=\"\")
    print()
# end
///////////////////////////////////////////////
"

.projectP23<-"ASCII art (make art) [original code]
////////////////////////////////////////////////
#!/usr/bin/env python3
# pip3 install opencv-python
import cv2
import numpy as np

import sys

symbols_list = [\"#\", \"-\", \"*\", \".\", \"+\", \"o\"]
threshold_list = [0, 50, 100, 150, 200]

def print_out_ascii(array):
    \"\"\"prints the coded image with symbols\"\"\"

    for row in array:
        for e in row:
        	# select symbol based on the type of coding
            print(symbols_list[int(e) % len(symbols_list)], end=\"\")
        print()


def img_to_ascii(image):
    \"\"\"returns the numeric coded image\"\"\"

    # resizing parameters
    # adjust these parameters if the output doesn't fit to the screen
    height, width = image.shape
    new_width = int(width / 20) 
    new_height = int(height / 40)

    # resize image to fit the printing screen
    resized_image = cv2.resize(image, (new_width, new_height),)

    thresh_image = np.zeros(resized_image.shape)

    for i, threshold in enumerate(threshold_list):
        # assign corresponding values according to the index of threshold applied
        thresh_image[resized_image > threshold] = i
    return thresh_image


if __name__ == \"__main__\":
    if len(sys.argv) < 2:
        print(\"Image Path not specified : Using sample_image.png\n\")
        image_path = \"sample_image.png\"  # default image path

    if len(sys.argv) == 2:
        print(\"Using {} as Image Path\n\".format(sys.argv[1]))
        image_path = sys.argv[1]

    image = cv2.imread(image_path, 0)  # read image

    ascii_art = img_to_ascii(image)
    print_out_ascii(ascii_art)

////////////////////////////////////////////////
"

.projectP24<-"Speech to text 
////////////////////////////////////////////////
import pyaudio  #pip install SpeechRecognition   # spelling!!
import speech_recognition
#
outfile=\"t.txt\"
def record_voice():
	microphone = speech_recognition.Recognizer()	
	with speech_recognition.Microphone() as live_phone:
		microphone.adjust_for_ambient_noise(live_phone)
		print(\"I'm trying to hear you: \")
		audio = microphone.listen(live_phone)
		try:
			phrase = microphone.recognize_google(audio, language='en')
			return phrase
		except speech_recognition.UnkownValueError:
			return \"I didn't understand what you said\"
#
x= record_voice()
with open(outfile,'w') as file:
    file.write(x) 
#
print('check',outfile) 
////////////////////////////////////////////////
"

.projectP25<-"Issue with the Python PyAudio module 
////////////////////////////////////////////////
1) Issues
---------------------------------------
 Running setup.py clean for pyaudio
Failed to build pyaudio
Installing collected packages: pyaudio
    Running setup.py install for pyaudio ... error

Solution:  
python -m pip install pipwin

#and after some time.

pipwin install pyaudio

https://cppsecrets.com/users/11429798104105115104101107117115104119971049754494864103109971051084699111109/python-pyAudio-failed-to-install-Windows-10.php

////////////////////////////////////////////////
"

.projectP26<-"sys.argv explanation 
////////////////////////////////////////////////
def dd(x):
    a=2*x
    return(a)
#
print(\"Input a value\")
x=float(input())
a=dd(x)
print('The answer is')
print(a)

$python c:\\temp\\myfun.py 

import sys
print(\"This is the name of the script: \", sys.argv[0])
print(\"Number of arguments: \", len(sys.argv))
print(\"The arguments are: \" , str(sys.argv))

////////////////////////////////////////////////
"

.projectP27<-"
////////////////////////////////////////////////
import re
import requests
import pandas as pd
from bs4 import BeautifulSoup
 
url='https://scholar.google.com/citations?hl=en&user=8tJwk2IAAAAJ'
resp=requests.get(url)
x=BeautifulSoup(resp.text,'html.parser')    
#
#x2=pd.DataFrame(x)
#x2.to_clipboard()
x2=str(x)

////////////////////////////////////////////////
"

.projectP28<-"more complete code
////////////////////////////////////////////////
import re
import requests
import pandas as pd
from bs4 import BeautifulSoup
 
url='https://scholar.google.com/citations?hl=en&user=8tJwk2IAAAAJ'
resp=requests.get(url)
x=BeautifulSoup(resp.text,'html.parser')    
#
#x2=pd.DataFrame(x)
#x2.to_clipboard()
x2=str(x)

n=x2.find(\"Cited\")
x3=x2[n:n+20]
citation=re.sub(\"\\D\",\"\",x3)
print(\"Total citation=\",citation)

n=x2.find(\">h-index<\")
x3=x2[n:n+50]
a=re.sub(\"\\D\",\"\",x3)
print(\"h-index=\",a)

n=x2.find(\">i10-index<\")
x3=x2[n:n+50]
a=re.sub(\"(>i10-index)\",\"\",x3)
a2=re.sub(\"\\D\",\"\",a)
print(\"i10-index=\",a2)
////////////////////////////////////////////////
"

.projectP29<-"screenshot every 4 seconds
////////////////////////////////////////////////
import os
import time
import argparse
import pyautogui
# click the red icon to stop !!!!!!
skipSeconds=4.              

try:
    while True:
        t = time.localtime()
        current_time = time.strftime(\"%H_%M_%S\", t)
        file = \"t\"+current_time + \".jpg\"
        image = pyautogui.screenshot(os.path.join(file))
        print(f\"{file} saved successfully.\\n\")
        time.sleep(skipSeconds)
except KeyboardInterrupt:  
    print(\"          End of script by user interrupt\")

////////////////////////////////////////////////
"

.projectP30<-"screenshot every 4 seconds {II}
////////////////////////////////////////////////
import os
import time
import argparse
import pyautogui
#
# click the red icon to stop !!!!!!
locationImages=\"./images\"
skipSeconds=4.              

if os.path.isdir(locationImages) != True:
    os.mkdir(locationImages)
#
try:
    while True:
        t = time.localtime()
        current_time = time.strftime(\"%H_%M_%S\", t)
        file = \"t\"+current_time + \".jpg\"
        image = pyautogui.screenshot(os.path.join(locationImages,file))
        print(f\"{file} saved successfully.\\n\")
        time.sleep(skipSeconds)
except KeyboardInterrupt:  
    print(\"          End of script by user interrupt\")
////////////////////////////////////////////////
"

.projectP31<-"screenshot every 4 seconds {original code}
////////////////////////////////////////////////

import os
import argparse
import pyautogui
import time

parser = argparse.ArgumentParser()

parser.add_argument(\"-p\", \"--path\", help=\"absolute path to store screenshot.\", default=r\"./images\")
parser.add_argument(\"-t\", \"--type\", help=\"h (in hour) or m (in minutes) or s (in seconds)\", default='h')
parser.add_argument(\"-f\", \"--frequency\", help=\"frequency for taking screenshot per h/m/s.\", default=1, type=int)

args = parser.parse_args()


sec = 0.

if args.type == 'h':
    sec = 60 * 60 / args.frequency
elif args.type == 'm':
    sec = 60 / args.frequency

if sec < 1.:
    sec = 1.
    

if os.path.isdir(args.path) != True:
    os.mkdir(args.path)


try:
    while True:
        t = time.localtime()
        current_time = time.strftime(\"%H_%M_%S\", t)
        file = current_time + \".jpg\"
        image = pyautogui.screenshot(os.path.join(args.path,file))
        print(f\"{file} saved successfully.\n\")
        time.sleep(sec)
        
except KeyboardInterrupt:
    print(\"End of script by user interrupt\")
////////////////////////////////////////////////
"

.projectP32<-"find dominant color for a given image
////////////////////////////////////////////////
import cv2
import numpy as np

infile=\"c://temp/fun.png\"

img = cv2.imread(infile)
cv2.imshow(\"img\", img)
array = np.array(img)
unique, counts = np.unique(array, return_counts=True)
ocurrance = dict(zip(unique, counts))
a1_sorted_keys = sorted(ocurrance, key=ocurrance.get, reverse=True)
print(a1_sorted_keys[:3])
image=np.zeros((300,300,3),np.uint8) # Create a blank 300x300 black image
image[:] = a1_sorted_keys[:3]        # Fill image with red color(set each pixel to red)
c = a1_sorted_keys[0]
color=np.zeros((300,300,3),np.uint8) # Create a blank 300x300 black image
color[:] = (c, c, c)                 # Fill image with red color(set each pixel to red)
print(\"Tone : \" + str(a1_sorted_keys[:3]))
cv2.imshow(\"Tone\", image)
print(\"color : \" + str([c, c, c]))
cv2.imshow(\"color\", color)

////////////////////////////////////////////////
"

.projectP33<-"find dominant color for a given image [original code]
////////////////////////////////////////////////
import cv2
import numpy as np

path = input(\"Enter Path :- \")
try:
    img = cv2.imread(path)
    cv2.imshow(\"img\", img)
except Exception:
    print(\"Path not found\")
    exit()


array = np.array(img)
unique, counts = np.unique(array, return_counts=True)

ocurrance = dict(zip(unique, counts))


a1_sorted_keys = sorted(ocurrance, key=ocurrance.get, reverse=True)
print(a1_sorted_keys[:3])


# Create a blank 300x300 black image
image = np.zeros((300, 300, 3), np.uint8)
# Fill image with red color(set each pixel to red)
image[:] = a1_sorted_keys[:3]

c = a1_sorted_keys[0]
# Create a blank 300x300 black image
color = np.zeros((300, 300, 3), np.uint8)
# Fill image with red color(set each pixel to red)
color[:] = (c, c, c)

print(\"Tone : \" + str(a1_sorted_keys[:3]))
cv2.imshow(\"Tone\", image)
print(\"color : \" + str([c, c, c]))
cv2.imshow(\"color\", color)
////////////////////////////////////////////////
"


.projectP34<-"password generator
////////////////////////////////////////////////
import random
import string
#
maxlen=8       # maximum lennth of your pawword
prefix='aa'    # a prefix and could be nothing
def get_random_char():
    chars = string.printable
    randomChar = chars[random.randint(0,len(chars)-1)]
    return randomChar
def stretch(text,maxlength):
    if len(text) < maxlength:
        randomChar = get_random_char()
        return stretch(text+randomChar,maxlength)
    else:
        return text
#
maxlength = int(maxlen)
pw=stretch(prefix,maxlength)
print(\"pw=|\",pw,\"|\\n\")
////////////////////////////////////////////////
"

.projectP35<-"password generator [original code]
////////////////////////////////////////////////
import random
import string

def stretch(text,maxlength):
    if len(text) < maxlength:
        randomChar = get_random_char()
        return stretch(text+randomChar,maxlength)
    else:
        return text

def get_random_char():
    chars = string.printable
    randomChar = chars[random.randint(0,len(chars)-1)]
    return randomChar

while 1:
    maxlen = input(' [?] Enter a length for your password (e for exit): ')
    try:
        maxlength = int(maxlen)
        print(\"'\",stretch('',maxlength),\"'\\n\")
    except:
        if maxlen == 'e':
            break
        print('Please Enter an integer')
////////////////////////////////////////////////
"


.projectP36<-"Fix issues when installing the moviepy Python module
////////////////////////////////////////////////
Error message
  OSError: MoviePy Error: creation of None failed because of the following error:
    [WinError 2] The system cannot find the file specified.

   .This error can be due to the fact that ImageMagick is not installed on your
    computer, or (for Windows users) that you didn't specify the path to the 
    ImageMagick binary in file conf.py, or that the path you specified is incorrect
 
 Step 1: Download and install imageMagic at
         https://imagemagick.org/
         https://imagemagick.org/script/download.php#windows

 Step 2: Find the location of magick.exe, e.g., 
         C:\\Program Files\\ImageMagick-7.1.0-Q16\\magick.exe

 Step 3: Find the location of config_defaults.py, e.g., 
         c://Users/pauly/anaconda3/lib/site-packages/moviepy/config_defaults.py

 Step 4: Open the config_default.py 
         Comment out the following line [should be the last line]
         #IMAGEMAGICK_BINARY = os.getenv('IMAGEMAGICK_BINARY', 'auto-detect')
         Add the following one based on step 2.
         IMAGEMAGICK_BINARY = r\"C:\\Program Files\\ImageMagick-7.1.0-Q16\\magick.exe\"

////////////////////////////////////////////////
"

.projectP37<-"Generate a png file
////////////////////////////////////////////////

from moviepy.editor import *
TextClip(txt=\"Python is great!\",fontsize=60,color=\"green\",bg_color=\"white\").save_frame(\"t.png\")


# alternatively

from moviepy.editor import *
x=TextClip(txt=\"Python is great!\",fontsize=60,color=\"green\",bg_color=\"white\")
x.save_frame(\"t.png\")

////////////////////////////////////////////////
"

.projectP38<-"cut your video 
////////////////////////////////////////////////

from moviepy.editor import *
VideoFileClip(\"coin14second.mp4\").subclip(10,14).write_videofile(\"coin2.mp4\",fps=25)


# laternatively
from moviepy.editor import *
x=VideoFileClip(\"coin14second.mp4\").subclip(10,14)
x.write_videofile(\"coin2.mp4\",fps=25)

////////////////////////////////////////////////
"

.projectP39<-"rotate your video 180 degree
////////////////////////////////////////////////

from moviepy.editor import *
VideoFileClip(\"bird.mp4\").rotate(180).write_videofile(\"t.mp4\",fps=25)

# alternatively
from moviepy.editor import *
x=VideoFileClip(\"bird.mp4\").rotate(180)
x.write_videofile(\"t.mp4\",fps=25)

////////////////////////////////////////////////
"


.projectP40<-"Generating a moving gif from a video
////////////////////////////////////////////////
# first 3 seconds

from moviepy.editor import *
VideoFileClip(\"bird.mp4\").subclip(0,3).write_gif(\"bird.gif\")

////////////////////////////////////////////////
"

.projectP41<-"Concatenate 2 videos  [3 lines]
////////////////////////////////////////////////

from moviepy.editor import *
a=VideoFileClip
concatenate_videoclips([a(\"bird.mp4\"),a(\"abstract.mp4\")]).write_videofile(\"m2.mp4\",fps=25)


# alternatively
from moviepy.editor import *
v1 = VideoFileClip(\"bird.mp4\")
v2 = VideoFileClip(\"abstract.mp4\")
x= concatenate_videoclips([v2, v1])
x.write_videofile(\"m2.mp4\",fps=25)

////////////////////////////////////////////////
"


.projectP42<-"Combining several images to a video
////////////////////////////////////////////////

from moviepy.editor import *
allFrame=['f1.png','f2.png','f3.png','f4.png']
x= ImageSequenceClip(allFrame,fps=1)
x.write_videofile('t.mp4',fps=25)

////////////////////////////////////////////////
"

.projectP43<-"moviepy:add a text to your video
////////////////////////////////////////////////

from moviepy.editor import *
a=TextClip(\"Happy Bird!\",fontsize=70,color='red')
v = VideoFileClip(\"bird.mp4\").subclip(1,5)
txt=(a.set_position('top') .set_duration(5))
CompositeVideoClip([v, txt]).write_videofile(\"new.mp4\",fps=25)

////////////////////////////////////////////////
"

.projectP44<-"Moving gif from a set of images (*.jpg)
////////////////////////////////////////////////
#  assume the follwoing3 images are unger c://temp/ttt
#  milkyWay.jpg, todayAtGeneseo.jpg ,vacation_2017.jpg 

import glob
from PIL import Image
frames = [Image.open(image) for image in glob.glob(f\"ttt/*.JPG\")]
out = frames[1]   # use todayAtGeneseo.jpg
out.save(\"my.gif\", format=\"GIF\", append_images=frames,save_all=True,duration=10, loop=0)

////////////////////////////////////////////////
"

.projectP45<-"Video to one image
////////////////////////////////////////////////

from moviepy.editor import VideoFileClip, ImageClip
#  ----input areas -----------------------
infile=\"bird.mp4\"
outfile=\"average2.png\"
fps=1.0         # fps is frame per second  
#------------------------------------------
clip = VideoFileClip(infile)
nframes = clip.duration*fps # total number of frames used
total_image = sum(clip.iter_frames(fps,dtype=float,logger='bar'))
average_image = ImageClip(total_image/ nframes)
average_image.save_frame(outfile)

////////////////////////////////////////////////
"

.projectP46<-"make a short video
////////////////////////////////////////////////

mport moviepy.editor as mp
#---  input area --------------------------------
outfile=\"test.mp4\"
w=500   # width 
h=300   # high
# -----------------------------------------------
messages = [\"Dog\", \"Cat\", \"Duck\", \"Wolf\"]
clips=[mp.TextClip(txt,fontsize=170,color='green', size=(w,h))
       .set_duration(1)
       for txt in  messages]
out = mp.concatenate_videoclips(clips)
out.write_videofile(outfile,fps=25)

 source: https://stackoverflow.com/questions/28758474/how-to-concatenate-videos-in-moviepy

////////////////////////////////////////////////
"

.projectP47<-"Cool effect
////////////////////////////////////////////////
# http://datayyy.com/videos/danl100.avi

import numpy as np
from moviepy.editor import *
from moviepy.video.tools.segmenting import findObjects
#--------input area----------------------------------
x=\"DANL100 Cool\"
outfile=\"danl100.avi\"
screensize = (720,460)
#-----------------------------------------------------
txtClip = TextClip(x,color='white',font=\"Amiri-Bold\",kerning = 5, fontsize=100)
cvc = CompositeVideoClip( [txtClip.set_pos('center')],size=screensize)
rotMatrix = lambda a: np.array( [[np.cos(a),np.sin(a)],[-np.sin(a),np.cos(a)]] )
#
def vortex(screenpos,i,nletters):
    d = lambda t : 1.0/(0.3+t**8)  # damping
    a = i*np.pi/ nletters          # angle of the movement
    v = rotMatrix(a).dot([-1,0])
    if i%2 : v[1] = -v[1]
    return lambda t: screenpos+400*d(t)*rotMatrix(0.5*d(t)*a).dot(v)
def cascade(screenpos,i,nletters):
    v = np.array([0,-1])
    d = lambda t : 1 if t<0 else abs(np.sinc(t)/(1+t**4))
    return lambda t: screenpos+v*400*d(t-0.15*i)
def arrive(screenpos,i,nletters):
    v = np.array([-1,0])
    d = lambda t : max(0, 3-3*t)
    return lambda t: screenpos-400*v*d(t-0.2*i)
def vortexout(screenpos,i,nletters):
    d = lambda t : max(0,t)     # damping
    a = i*np.pi/ nletters       # angle of the movement
    v = rotMatrix(a).dot([-1,0])
    if i%2 : v[1] = -v[1]
    return lambda t:screenpos+400*d(t-0.1*i)*rotMatrix(-0.2*d(t)*a).dot(v)
def moveLetters(letters, funcpos):
    return [letter.set_pos(funcpos(letter.screenpos,i,len(letters)))
              for i,letter in enumerate(letters)]
letters = findObjects(cvc) # a list of ImageClips
clips = [ CompositeVideoClip( moveLetters(letters,funcpos),
                              size = screensize).subclip(0,5)
          for funcpos in [vortex, cascade, arrive, vortexout] ]
final_clip = concatenate_videoclips(clips)
final_clip.write_videofile(outfile,fps=25,codec='mpeg4')
////////////////////////////////////////////////
"

.projectP48<-"sin moving video (5 second)
////////////////////////////////////////////////

import numpy as np
import matplotlib.pyplot as plt
from moviepy.editor import VideoClip
from moviepy.video.io.bindings import mplfig_to_npimage
#
outfile=\"sin.mp4\"           # output mp4 file
x = np.linspace(-2, 2, 200) # numpy array
fig, ax = plt.subplots()    # matplot subplot
myduration=5                # in second 
#
def make_frame(t):          # method to get frames
    ax.clear()              # clear
    ax.plot(x,np.sin(x+2*np.pi/myduration*t),lw=3)
    ax.set_ylim(-1.5,2.5)
    return mplfig_to_npimage(fig)
# 
clip=VideoClip(make_frame,duration=myduration)  # video clip
clip.write_videofile(outfile,fps=25)

# https://www.geeksforgeeks.org/moviepy-creating-video-clip/
////////////////////////////////////////////////
"


.projectP49<-"Sources of free vidoes, images, music and sound
////////////////////////////////////////////////
 Sources of free videos, images, and sounds

  Pexels.com
      https://www.pexels.com/

  Pixabay.com
      https://pixabay.com/

  YouTube
      YouTube -> your videos -> Audio library

////////////////////////////////////////////////
"

.projectP50<-"Retrieve text from image
////////////////////////////////////////////////
# step #1: pip install pytesseract
# step #2: download and install tesseract.exe at
# https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-v4.1.0-bibtag19.exe

import pytesseract
from PIL import Image
infile='c://temp/preview.jpg'

# add the path
exePath=r\"C:\\Program Files\\Tesseract-OCR\\tesseract.exe\"
pytesseract.pytesseract.tesseract_cmd =exePath
image = Image.open(infile)
x = pytesseract.image_to_string(image, lang='eng')
with open('c://temp/t.txt', 'w') as f:
    f.write(x)

////////////////////////////////////////////////
"
.projectP51<-"
////////////////////////////////////////////////

////////////////////////////////////////////////
"
.projectP52<-"
////////////////////////////////////////////////

////////////////////////////////////////////////
"



.projectP843<-"Add a text to a video
////////////////////////////////////////////////

from moviepy.editor import *
# -- input area ------------------------
infile=\"bird.mp4\"     # input file mp4
outfile=\"bird3.mp4\"   # output file mp4
x=\"Happy Birthday!\"   # our text 
start=3               # starting second
end=8                 # ending second
duration=5            # duration of the text
# ---------------------------------
----
clip = VideoFileClip(infile) 
clip = clip.subclip(start, end) 
clip = clip.volumex(0.8)                       # Reduce volume x 0.8 
txt_clip=TextClip(x,fontsize =75,color='pink') # Generate a text clip 
txt_clip=txt_clip.set_pos('top')               # choose location 
txt_clip=txt_clip.set_duration(duration)       # choose duration 
video = CompositeVideoClip([clip, txt_clip])   # overlay the text
video.write_videofile(outfile,fps=25)          # save it

////////////////////////////////////////////////
"

