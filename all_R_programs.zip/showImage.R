.showImage<-function(name){
"Objective: show a formula from http://datayyy.com/getdata/images/

 Example #1>infile<-'http://datayyy.com/rpy/code/haha.png'
           >.imgage(infile)

 Example 2:>infile<-'http://datayyy.com/rpy/codeImage/c1_oneLine_danl100.png'
           > .showImage(infile)

";.zshowImage_(name)}

.zshowImage_<-function(name){

   .path3<-"http://datayyy.com/getdata/images/"
   if(exists('.imageData')==FALSE){
         .tempPath<-paste0(.path3,"imageList",".RData")
        .imageData<<-get(load(url(.tempPath)))
   }


   library(png)
   .td = tempdir()        
   .tf = tempfile(tmpdir=.td, fileext=".png")
   .ttt<-paste(name,".png",sep='')

   if(typeof(name)=="character"){
        .myPNG<-name
   }else{
      a<-.imageData$NAME[name]
      .myPNG <- paste0('http://datayyy.com/getdata/images/',a)
      download.file(.myPNG, .tf, quiet = TRUE,mode = 'wb')
      graphics.off()
      .img <- readPNG(.tf)
      grid::grid.raster(.img)
  }
}

