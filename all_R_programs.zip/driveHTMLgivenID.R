.driveHTMLgivenID<-function(id){
"Objective: manually download a file from my Google Drive 
   data_ID : an integer 

 Example #1:> driveHTMLgivenID('1HEm2rDEuoRgkum7QlUSUkWStuFds5vyJ')
              The link for  ibmMonthly.csv :
                https://drive.google.com/uc?id=1HEm2rDEuoRgkum7QlUSUkWStuFds5vyJ&export=download 

     
";.driveHTMLgivenID_(id)}

.dr5<-.driveHTMLgivenID

.driveHTMLgivenID_<-function(id){
    a<-"https://drive.google.com/uc?id="
    b<-"&export=download"
    html<-paste0(a,id,b)
    cat(" The web link is:\n")
    cat("   ",html, "\n")
}









