.get_10Kwebs2019q1<-function(cik){
"Objective: Get the web locations for agiven CIK
              2019 Q1 only 

  Example #1>.get_10Kwebs2019q1(1141807)

";.zget_10Kwebs2019q1(cik)}


.zget_10Kwebs2019q1<-function(cik){

    if(exists('.web10k')==FALSE){
        .web10k<<-get(load(url("http://datayyy.com/getdata/index10k2019q1.RData")))
    }

   a<-grep(cik,.web10k$CIK)


   n<-length(a)
   if(n==1){
       out<-.web10k[a,]
   }else if(n>1){
       out<-.web10k[a,]
       out2<-out[nchar(out$CIK)==nchar(cik),]
   }else{
       cat("no such a CIK \n")
       break
   }
   rownames(out2)<-NULL
   #return(out)
   out2$LOC<-paste0("https://www.sec.gov/Archives/edgar/data/",out2$CIK,"/",out2$LOC,".txt")
   print(out2,row.names=F)
}





