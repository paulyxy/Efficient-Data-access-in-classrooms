"

setwd('c://yan/teaching/getdata/R/')
source('activatePrograms.R')

source('c://R/getdata.txt')
"
rm(list=ls(all=TRUE))

x<-dir(patter=".R$")
x2<-x[-grep("activateP",x)]
n<-length(x2)

#for(i in 1:n){


for(i in 1:n){
  cat(x2[i],"\n")
  source(x2[i])

}


rm(list=ls())

if(exists("..week")==TRUE)rm(..week)
if(exists("..week2")==TRUE)rm(..week2)

base::save.image('activatePrograms.RData')

