.countComma<-function(x,sep=","){

    n<-length(x)
    diff<-NULL
    for(i in 1:n){
        a<-x[i]
        n1<-nchar(a)
        b<-gsub(sep,"",a)
        n2<-nchar(b)
        diff[i]<-n1-n2
    }
    final<-data.frame(1:n,diff)
    colnames(final)<-c("I","NUMBER")
    return(final)
}



