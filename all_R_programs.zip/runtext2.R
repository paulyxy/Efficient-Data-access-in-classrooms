
.runText<-function(string){
"Objective: run a command expressed as a string


  Example 1: > x<-1:50
             > a<-'mean(x)'
             > .runText(a)
               [1] 25.5

  Example 2: > x<- double quotation mak here source('http://canisius.edu/~yany/adv.R')    double quotation mark here  
             >runText(x)

"

.runText_(string)
}

.runText_<-function(string){
    .cc = parse(text =string) 
    eval(.cc) 
}


