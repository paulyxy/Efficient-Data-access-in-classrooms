.printLeftAdj<-function(x){
"Objective: left-adjusted both contents and column names 

 Exampe 1:> b
          DATE        PACKAGE                                                            TITLE
  1 2020-11-09           FAwR             Functions and Datasets for 'Forest Analytics with R'
  2 2020-11-09             hR                    Toolkit for Data Analytics in Human Resources
  3 2020-09-18           TCIU Spacekime Analytics; Time Complexity and Inferential Uncertainty
  4 2020-08-26  radiant.model     Model Menu for Radiant: Business Analytics using R and Shiny
  5 2020-08-07   radiant.data      Data Menu for Radiant: Business Analytics using R and Shiny
  6 2020-08-03 paws.analytics                           Amazon Web Services Analytics Services

  > .printLeftAdj(b)
  DATE       PACKAGE        TITLE                                                           
1 2020-11-09 FAwR           Functions and Datasets for 'Forest Analytics with R'            
2 2020-11-09 hR             Toolkit for Data Analytics in Human Resources                   
3 2020-09-18 TCIU           Spacekime Analytics; Time Complexity and Inferential Uncertainty
4 2020-08-26 radiant.model  Model Menu for Radiant: Business Analytics using R and Shiny    
5 2020-08-07 radiant.data   Data Menu for Radiant: Business Analytics using R and Shiny     
6 2020-08-03 paws.analytics Amazon Web Services Analytics Services        


";.printLeftAdj_(x)}


.pla<-.printLeftAdj

.printLeftAdj_<-function(x){
   print(x,right=F)

}


