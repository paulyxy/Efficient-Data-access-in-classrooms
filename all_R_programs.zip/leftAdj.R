.leftAdj<-function(x){
   format(x, justify = "left")

}
