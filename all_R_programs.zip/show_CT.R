.show_CT<-function(n=2){
"Objective: CT stands for Conslidated Quote
            High-frequency data

 Example 1:> .show_CT()    # show the first two lines

 Example 2:> .show_CT(-4)  # show the last three observations

 Example 3:> .show_CT(0)
             Launch Excel and paste

";.zshow_CT(n)}

.zshow_CT<-function(n){
   if(exists('.ctData')==FALSE){
      .ctData<<-get(load(url('http://datayyy.com/data_R/TORQct.RData')))
   }
   .show_n_obs(.ctData,n)
}
