.copy2Excel<-function(data){
"Objective: copy a data set to Excel 
   data   : input data set
            Note that: .c2e is the short-cut

 Example #1>x=matrix(1:10,5,2)
           >.copy2Excel(x)
             Launch Excel and paste

 Example #2>x=matrix(1:10,5,2)
           >.c2e(x)
             Launch Excel and paste

 Example #3>set.seed(123)
           > x=matrix(rnorm(500),100,5)
           > .c2e(x)
             Launch Excel and paste

";.copy2Excel_(data)}

.copy2excel<-.copy2Excel
.c2e<-.copy2Excel

.copy2Excel_<-function(data){
    write.table(data,file="clipboard-16384", sep="\t", row.names=FALSE)
    cat(" Launch Excel and paste\n\n")
}

