.exam<-function(keyword){
"Objective: check the final exam schedule (Spring 2022)
   keyword: input such as 'TR8', 'TR11'
            source of data: http://datayyy.com/doc_pdf/exam2022s.pdf

 Example #1> .exam('mwf8:30')
                       DATE                           TIME       COURSE
         1 Wednesday.May.18 8:00-10:30am(3)8:00-11:20am(4) MWF8:30-9:20

 Example #2>.exam('mw2:30')
                DATE                           TIME                 COURSE
     1 Monday.May.16 12:00-2:30pm(3)12:00-3:20pm(4)          MWF12:30-1:20
     2 Monday.May.16 12:00-2:30pm(3)12:00-3:20pm(4) MW/MF/WF12:30-2:10 (4)

 Example #3> .exam('mw5:00')
               DATE                         TIME      COURSE
    1 Friday.May.20 3:30-6:00pm(3)3:30-6:50pm(4) MW5:00-6:15

";.exam_(keyword)}

.exam_<-function(keyword){
  if(exists('.examData')==FALSE){
     infile<-"http://datayyy.com/data_R/exam2022spring.RData"
     .examData<<-get(load(url(infile)))
   }

   keyword2<-toupper(keyword)

   time<-gsub("[a-zA-Z]","",keyword2)
   letters<-gsub("[^a-zA-Z]","",keyword2)
   nLetters<-nchar(letters)

   phrase<-paste0(letters,".*",time)
   n<-grep(phrase,.examData$COURSE)
   final<-.examData[n,]
   rownames(final)<-NULL
   return(final)
}






 