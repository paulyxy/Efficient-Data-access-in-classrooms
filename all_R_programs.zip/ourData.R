.ourData<-function(keyword_or_ID){
"Objective: find the data ID for a given keyword

 Example #1:>.ourData('f-f')
      ID                                                             NAME
       5 http://datayyy.com/data_csv/F-F_Research_Data_Factors2.csv      
       6 http://datayyy.com/data_csv/F-F_Research_Data_Factors_daily2.csv
      90 http://datayyy.com/data_txt/F-F_Research_Data_Factors.txt       
      91 http://datayyy.com/data_txt/F-F_Research_Data_Factors2.txt      
      92 http://datayyy.com/data_txt/F-F_Research_Data_Factors_daily.txt 
      93 http://datayyy.com/data_txt/F-F_Research_Data_Factors_daily2.txt
      
 Example #2: > ourData(90)  # will go to that data set

 Example #3: >.ourData(0) 
            Window users: launch Excel/paste a list of data sets

";.zourData(keyword_or_ID)}

.zourData<-function(keyword_or_ID){
   if(exists('.oData')==FALSE){
      .tempPath<-'http://datayyy.com/data_R/ourData.RData'
      x<-get(load(url(.tempPath)))
      n<-nrow(x)
      .oData<-data.frame(1:n,x)
      colnames(.oData)<-c("ID","NAME")
      .oData<<-.oData
   }

   n<-nrow(.oData)
       
  if(typeof(keyword_or_ID)=="double"){
       if(keyword_or_ID==0){
           write.table(.oData,file="clipboard-16384", sep="\t", row.names=FALSE)
           cat(" Window users: launch Excel/paste a list of data sets\n\n")
       }else{
           out<-.oData$NAME[keyword_or_ID]
           browseURL(out)
        }
    }else{
      .a<-tolower(keyword_or_ID)
      .b<-tolower(.oData$NAME)
      .z<-.oData[grep(.a,.b),]
      #rownames(.z)<-NULL
      print(.leftAdj(.z),row.names=F)
   }
}








