.get_CIKgivenTicker<-function(ticker){
"Objective: get a CIK for a given ticker 
   ticker : ticker symbol such as 'ibm'

  Example #1>.getCIK('ibm')
               TICKER   CIK
             1    IBM 51143

  Example #2:>.getCIK('wmt')
               TICKER     CIK
             1    WMT  104169

  Example #3:>.getCIK('jnj')
               TICKER    CIK
             1    JNJ 200406

  Example #4>.getCIK('msft')
               TICKER    CIK
             1   MSFT 789019

";.zget_CIKgivenTicker(ticker)}

.zget_CIKgivenTicker<-function(ticker){

    if(exists('.cikTicker')==FALSE){
        .cikTicker<<-get(load(url("http://datayyy.com/data_R/cikTicker.RData")))
    }

   ticker<-toupper(ticker)
   a<-grep(ticker,.cikTicker$TICKER)
   n<-length(a)

   if(n==1){
       cik<-.cikTicker[a,]
   }else{
       b<-.cikTicker[a,]
       cik<-b[nchar(ticker)==nchar(b$TICKER),]
   }
   rownames(cik)<-NULL
   return(cik)
}





